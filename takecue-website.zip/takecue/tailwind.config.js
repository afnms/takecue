/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#111111',
        coal: '#171717',
        paper: '#FFFFFF',
        felt: '#1E402B',
        'felt-deep': '#163120',
      },
      fontFamily: {
        sans: ['"Cormorant Garamond"', 'Cormorant', 'Garamond', 'Georgia', 'serif'],
        // labels and numerals use the same family, set in small caps-style tracking
        mono: ['"Cormorant Garamond"', 'Garamond', 'Georgia', 'serif'],
      },
      letterSpacing: {
        tightest: '-0.025em',
      },
    },
  },
  plugins: [],
};
