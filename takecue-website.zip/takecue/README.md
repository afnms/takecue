# TAKE CUE — Website

Corporate site for **TAKE CUE · كيو الاستشارية لتطوير الأعمال**, a business development consultancy.
*Take the Cue. From Building to Beyond.*

Stack: React 18 · TypeScript · Tailwind CSS · GSAP ScrollTrigger · Lenis · Three.js · Vite.
Typeface: Cormorant Garamond (self-hosted via Fontsource, weights 400–700).

## Run

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build → dist/
npm run preview   # serve dist/ locally
```

`dist/` is a static site: deploy it to any static host (Vercel, Netlify, Cloudflare Pages, S3 + CloudFront, Nginx).
Enable gzip/brotli on the host (the 3D chunk is 481 KB raw, 120 KB gzipped).

## Structure

| Path | What it is |
| --- | --- |
| `src/content.ts` | **All approved copy and contact details.** Edit text here only. |
| `src/three/physics.ts` | Closed-form shot simulation (strike → cut-shot collision → roll-out) and scroll→time warp. Fully reversible when scrolling back. |
| `src/three/BilliardEngine.ts` | WebGL scene: table, balls, cue, lighting, cinematic camera path, 8D orbit. |
| `src/three/textures.ts` | Procedural textures (sphere-projected "8" decal, felt, shadows). No image downloads. |
| `src/three/cinematic.ts` | Post-processing: depth of field with focus pulls, bloom, film grade, grain, vignette and lens fringing. Also the lamp light shafts and dust motes. |
| `src/three/EightBallMini.ts` | The eight ball in the contact section. |
| `src/lib/timeline.ts` | Story beats shared by the 3D scene and the text overlays. |
| `src/components/*` | Page sections: Story (Hero + Who We Are), Framework, Services, Clients, Why, Philosophy, Contact, Footer, Nav. |

## Experience map

1. **Scene 01 – The Starting Point**: the cue ball alone under a single lamp (hero).
2. **Scene 02 – The Right Direction**: the table is revealed and the cue lines up (Who We Are).
3. **Scene 03 – The Strategic Move**: the cue strikes, the ball rolls, and the cut shot hits the eight ball in slow motion.
4. **Scene 04 – The Eight Dimensions**: the eight ball rolls to rest with its "8" facing the camera, and an orbit of eight markers appears.
5. **8D Framework**: pinned stepper. Scroll, use the stage list or the progress bar, or click the 3D markers.

## Accessibility & performance

- `prefers-reduced-motion`: no pinning and no smooth scroll. The 3D scene renders one still frame, and all eight dimensions show as cards.
- WebGL unavailable: CSS-drawn balls replace the scene.
- The render loop stops once the opaque sections cover the canvas, and pixel ratio drops automatically if frames are slow.
- The mobile quality tier lowers texture and shadow resolution.
- Three.js is code-split and loaded after first paint.
- Quality tiers: "high" (desktop, more than 4 CPU cores) adds depth of field and MSAA; "low" (phones and smaller machines) keeps bloom, grade and grain. Force one with `?quality=high` or `?quality=low`. If frames stay slow, the engine sheds resolution first, then depth of field, then bloom.
- Debug: append `?debug` to the URL to expose `window.__engine` (camera, cue, `debugCam` override).

## Brand assets

The official CUE logo was supplied as a bitmap inside `Cue_logo.svg`. It has been vector-traced so it stays sharp at every size:

- `src/components/logoPaths.ts`: mark and lockup paths used by `Logo` (nav) and `LogoLockup` (footer).
- `public/brand/cue-mark-{white,black}.svg` and `cue-lockup-{white,black}.svg`: standalone files.
- `public/favicon.svg` and `public/apple-touch-icon.png`: the mark on brand green.

If the designer has the original vector master (AI/EPS/PDF), drop its paths into `logoPaths.ts` for a perfect 1:1 match.

## Before launch

- Add `<link rel="canonical">` / `og:url` once the production domain is confirmed.
- `public/og-image.jpg` is a frame from the collision scene; swap it for a branded share image if preferred.
