import Lenis from 'lenis';
import { useEffect } from 'react';
import { Clients } from './components/Clients';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { Framework, FrameworkStatic } from './components/Framework';
import { Philosophy } from './components/Philosophy';
import { Services } from './components/Services';
import { Why } from './components/Why';
import { Nav } from './components/Nav';
import { SceneCanvas } from './components/SceneCanvas';
import { Story, StoryStatic } from './components/Story';
import { gsap, ScrollTrigger } from './lib/gsap';
import { registerScroller, scrollToId } from './lib/scroll';
import { useReducedMotion } from './lib/useReducedMotion';

export default function App() {
  const reduced = useReducedMotion();

  useEffect(() => {
    if (reduced) {
      registerScroller(null, true);
      return;
    }
    const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 0.9 });
    registerScroller(lenis, false);
    lenis.on('scroll', ScrollTrigger.update);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
      registerScroller(null, false);
    };
  }, [reduced]);

  // Deep links (#services etc.) once layout has settled.
  useEffect(() => {
    const id = window.location.hash.slice(1);
    const t = window.setTimeout(() => {
      ScrollTrigger.refresh();
      if (id) scrollToId(id);
    }, 400);
    document.fonts?.ready.then(() => ScrollTrigger.refresh());
    return () => window.clearTimeout(t);
  }, []);

  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-paper focus:px-4 focus:py-2 focus:text-ink">
        Skip to content
      </a>
      <Nav />
      {!reduced && <SceneCanvas reduced={false} />}
      <main id="main">
        {reduced ? (
          <StoryStatic>
            <SceneCanvas reduced />
          </StoryStatic>
        ) : (
          <Story />
        )}
        {reduced ? <FrameworkStatic /> : <Framework />}
        <Services reduced={reduced} />
        <Clients reduced={reduced} />
        <Why reduced={reduced} />
        <Philosophy reduced={reduced} />
        <Contact reduced={reduced} />
      </main>
      <Footer />
    </>
  );
}
