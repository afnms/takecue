import { useLayoutEffect, type RefObject } from 'react';
import { gsap } from './gsap';

/**
 * Fades/slides in every [data-reveal] element inside `root` as it enters view.
 * Lines drawn with [data-draw] (SVG paths using pathLength="1") are stroked in.
 */
export function useReveal(root: RefObject<HTMLElement>, reduced: boolean) {
  useLayoutEffect(() => {
    if (reduced || !root.current) return;
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
        gsap.from(el, {
          autoAlpha: 0,
          y: 34,
          duration: 1.1,
          ease: 'power3.out',
          delay: Number(el.dataset.delay || 0),
          scrollTrigger: { trigger: el, start: 'top 88%', once: true },
        });
      });
      gsap.utils.toArray<SVGPathElement>('[data-draw]').forEach((el) => {
        gsap.fromTo(
          el,
          { strokeDashoffset: 1 },
          {
            strokeDashoffset: 0,
            duration: 1.6,
            ease: 'power2.inOut',
            delay: Number(el.dataset.delay || 0),
            scrollTrigger: { trigger: el.closest('svg') ?? el, start: 'top 85%', once: true },
          },
        );
      });
    }, root);
    return () => ctx.revert();
  }, [root, reduced]);
}
