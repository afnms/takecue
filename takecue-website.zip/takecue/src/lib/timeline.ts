/**
 * Story beats, expressed as fractions of the pinned story section's scroll.
 * Shared by the 3D scene and the DOM overlays so they stay in lock-step.
 */
export const STORY = {
  heroOut: [0.05, 0.11] as const,
  cueEnter: [0.07, 0.2] as const,
  aboutIn: [0.13, 0.19] as const,
  aboutOut: [0.39, 0.43] as const,
  strokes: [0.2, 0.36] as const,
  drawBack: [0.36, 0.415] as const,
  strike: [0.415, 0.44] as const,
  contactTip: 0.44, // tip meets ball — ball starts rolling
  follow: [0.44, 0.47] as const,
  withdraw: [0.49, 0.6] as const,
  rollEnd: 0.82, // both balls at rest
  focus: [0.8, 0.95] as const,
  tableReveal: [0.06, 0.24] as const,
};

/** Scroll length of the story section, in viewport heights. */
export const STORY_VH = 720;
export const FRAMEWORK_STEP_VH = 70;

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const range = (v: number, a: number, b: number) => clamp((v - a) / (b - a));
export const smooth = (t: number) => t * t * (3 - 2 * t);
export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeIn = (t: number) => t * t;
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
