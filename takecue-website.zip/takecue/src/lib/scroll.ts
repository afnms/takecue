import type Lenis from 'lenis';
import { FRAMEWORK_STEP_VH } from './timeline';

let lenis: Lenis | null = null;
let reduced = false;

export function registerScroller(l: Lenis | null, isReduced: boolean) {
  lenis = l;
  reduced = isReduced;
}

export function scrollToY(y: number) {
  if (lenis) {
    const distance = Math.abs(y - window.scrollY);
    // Long jumps (through the story) play the shot fast-forward, but never sluggishly.
    const duration = Math.min(2.4, 0.8 + distance / 4000);
    lenis.scrollTo(y, { duration });
  } else {
    window.scrollTo({ top: y, behavior: reduced ? 'auto' : 'smooth' });
  }
}

export function scrollToId(id: string, offset = 0) {
  if (id === 'home') {
    scrollToY(0);
  } else {
    const el = document.getElementById(id);
    if (!el) return;
    scrollToY(el.getBoundingClientRect().top + window.scrollY + offset);
  }
  if (history.replaceState) history.replaceState(null, '', id === 'home' ? ' ' : `#${id}`);
}

/** Scroll the pinned 8D track so that a given dimension is centred in its step. */
export function scrollToStage(i: number) {
  const track = document.getElementById('framework-track');
  if (!track) return;
  if (reduced) {
    document.getElementById(`stage-${i + 1}`)?.scrollIntoView({ block: 'center' });
    return;
  }
  const top = track.getBoundingClientRect().top + window.scrollY;
  const step = (window.innerHeight * FRAMEWORK_STEP_VH) / 100;
  scrollToY(top + step * (i + 0.5));
}
