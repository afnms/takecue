import { CONTACT, FOOTER } from '../content';
import { scrollToId } from '../lib/scroll';
import { InstagramIcon, LogoLockup, MailIcon, WhatsAppIcon } from './Icons';

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink">
      <div className="hero-pad-x mx-auto max-w-[1440px] pb-8 pt-20 md:pt-28">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <LogoLockup className="h-24 w-auto sm:h-28" />
            <p className="mt-8 text-[2rem] font-semibold leading-none tracking-[-0.018em]">TAKE CUE.</p>
            <p className="mt-3 text-paper/60">{FOOTER.category}</p>
            <p className="mt-6 text-[19px] font-medium">{FOOTER.slogan}</p>
            <p lang="ar" dir="rtl" className="mt-3 text-left text-[17px] text-paper/45">
              {FOOTER.arabic}
            </p>
          </div>
          <nav aria-label="Footer" className="md:col-span-3 md:col-start-7">
            <p className="font-mono text-[12.5px] uppercase tracking-[0.28em] text-paper/40">Explore</p>
            <ul className="mt-5 space-y-3">
              {FOOTER.links.map((l) => (
                <li key={l.id}>
                  <a
                    href={`#${l.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToId(l.id);
                    }}
                    className="text-[17px] text-paper/85 transition-colors hover:text-paper"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div className="md:col-span-3">
            <p className="font-mono text-[12.5px] uppercase tracking-[0.28em] text-paper/40">Connect</p>
            <ul className="mt-5 space-y-3 text-[17px]">
              <li>
                <a href={CONTACT.whatsapp.href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 text-paper/85 hover:text-paper">
                  <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                </a>
              </li>
              <li>
                <a href={CONTACT.email.href} className="inline-flex items-center gap-3 text-paper/85 hover:text-paper">
                  <MailIcon className="h-4 w-4" /> Email
                </a>
              </li>
              <li>
                <a href={CONTACT.instagram.href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 text-paper/85 hover:text-paper">
                  <InstagramIcon className="h-4 w-4" /> Instagram
                </a>
              </li>
            </ul>
          </div>
        </div>

        <p aria-hidden="true" className="outline-8 mt-20 select-none whitespace-nowrap text-center text-[19vw] font-semibold leading-[0.8] tracking-[-0.027em] md:mt-28">
          TAKE CUE.
        </p>

        <div className="mt-10 flex flex-col justify-between gap-3 border-t border-white/10 pt-6 font-mono text-[12.5px] uppercase tracking-[0.2em] text-paper/45 sm:flex-row">
          <span>{FOOTER.copyright}</span>
          <span>From Building to Beyond.</span>
        </div>
      </div>
    </footer>
  );
}
