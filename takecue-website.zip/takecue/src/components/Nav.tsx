import { useEffect, useRef, useState } from 'react';
import { CONTACT, NAV } from '../content';
import { scrollToId } from '../lib/scroll';
import { Logo } from './Icons';

type NavId = (typeof NAV)[number]['id'];

/** Ordered checkpoints → which nav item is current. */
const REGIONS: { el: string; nav: NavId }[] = [
  { el: 'home', nav: 'home' },
  { el: 'about', nav: 'about' },
  { el: 'framework', nav: 'framework' },
  { el: 'services', nav: 'services' },
  { el: 'clients', nav: 'services' },
  { el: 'why', nav: 'services' },
  { el: 'philosophy', nav: 'services' },
  { el: 'contact', nav: 'contact' },
];

export function Nav() {
  const [active, setActive] = useState<NavId>('home');
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setScrolled(window.scrollY > 40);
      const probe = window.innerHeight * 0.45;
      let current: NavId = 'home';
      for (const r of REGIONS) {
        const el = document.getElementById(r.el);
        if (el && el.getBoundingClientRect().top <= probe) current = r.nav;
      }
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    menuRef.current?.querySelector<HTMLElement>('a')?.focus();
    document.documentElement.classList.add('menu-open');
    return () => {
      window.removeEventListener('keydown', onKey);
      document.documentElement.classList.remove('menu-open');
    };
  }, [open]);

  const go = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setOpen(false);
    scrollToId(id);
  };

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4 sm:px-6 sm:pt-5">
        <nav
          aria-label="Primary"
          className={`mx-auto flex max-w-[1440px] items-center justify-between rounded-full border px-4 py-2.5 transition-all duration-500 sm:px-5 ${
            scrolled
              ? 'border-white/10 bg-ink/90 shadow-[0_10px_40px_-12px_rgba(0,0,0,0.6)] backdrop-blur-xl'
              : 'border-transparent bg-transparent'
          }`}
        >
          <a href="#home" onClick={go('home')} className="text-paper" aria-label="TAKE CUE — back to top">
            <Logo className="h-[22px] w-auto sm:h-6" />
          </a>
          <ul className="hidden items-center gap-1 lg:flex">
            {NAV.map((item) => (
              <li key={item.id}>
                <a
                  href={`#${item.id}`}
                  onClick={go(item.id)}
                  aria-current={active === item.id ? 'true' : undefined}
                  className={`group relative block px-3.5 py-2 text-[13px] font-medium uppercase tracking-[0.2em] transition-colors ${
                    active === item.id ? 'text-paper' : 'text-paper/55 hover:text-paper'
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute inset-x-3.5 -bottom-0.5 h-px origin-left bg-[#3c7a55] transition-transform duration-500 ${
                      active === item.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                    }`}
                  />
                </a>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-2">
            <a
              href={CONTACT.whatsapp.href}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden rounded-full bg-felt px-4 py-2 text-[13px] font-medium uppercase tracking-[0.18em] text-paper transition-colors hover:bg-paper hover:text-ink sm:inline-flex"
            >
              Let's Talk
            </a>
            <button
              type="button"
              className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/15 lg:hidden"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((o) => !o)}
            >
              <span className={`absolute h-px w-4 bg-paper transition-transform duration-300 ${open ? 'rotate-45' : '-translate-y-[3px]'}`} />
              <span className={`absolute h-px w-4 bg-paper transition-transform duration-300 ${open ? '-rotate-45' : 'translate-y-[3px]'}`} />
            </button>
          </div>
        </nav>
      </header>

      <div
        id="mobile-menu"
        ref={menuRef}
        className={`fixed inset-0 z-40 flex flex-col justify-between bg-ink px-6 pb-10 pt-28 transition-[opacity,visibility] duration-500 lg:hidden ${
          open ? 'visible opacity-100' : 'invisible opacity-0'
        }`}
        aria-hidden={!open}
      >
        <ul className="space-y-1">
          {NAV.map((item, i) => (
            <li key={item.id}>
              <a
                href={`#${item.id}`}
                onClick={go(item.id)}
                tabIndex={open ? 0 : -1}
                className="flex items-baseline gap-4 border-b border-white/10 py-4 text-[2rem] font-semibold tracking-tight"
              >
                <span className="font-mono text-xs text-paper/40">{String(i + 1).padStart(2, '0')}</span>
                <span className={active === item.id ? 'text-paper' : 'text-paper/80'}>{item.label}</span>
                {active === item.id && <span className="ml-auto h-2 w-2 self-center rounded-full bg-[#3c7a55]" />}
              </a>
            </li>
          ))}
        </ul>
        <div className="space-y-1 font-mono text-xs uppercase tracking-[0.18em] text-paper/50">
          <p>{CONTACT.email.display}</p>
          <p>{CONTACT.whatsapp.display}</p>
        </div>
      </div>
    </>
  );
}
