import { useLayoutEffect, useRef, useState } from 'react';
import { SERVICES, SERVICES_INTRO } from '../content';
import { ScrollTrigger } from '../lib/gsap';
import { scrollToId } from '../lib/scroll';
import { useReveal } from '../lib/useReveal';

export function Services({ reduced }: { reduced: boolean }) {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);
  useReveal(root, reduced);

  useLayoutEffect(() => {
    const triggers = SERVICES.map((_, i) =>
      ScrollTrigger.create({
        trigger: `#service-${i + 1}`,
        start: 'top 55%',
        end: 'bottom 55%',
        onToggle: (s) => s.isActive && setActive(i),
      }),
    );
    return () => triggers.forEach((t) => t.kill());
  }, []);

  return (
    <section id="services" ref={root} className="on-light relative bg-paper text-ink" aria-labelledby="services-title">
      <div className="hero-pad-x mx-auto grid max-w-[1440px] gap-14 py-24 md:grid-cols-12 md:gap-10 md:py-36">
        {/* sticky intro + index rail */}
        <div className="md:col-span-5">
          <div className="md:sticky md:top-32">
            <p className="kicker-dark" data-reveal>
              <span className="text-ink/40">03</span> — {SERVICES_INTRO.kicker}
            </p>
            <h2
              id="services-title"
              data-reveal
              className="mt-4 text-[clamp(2.6rem,5.4vw,5.6rem)] font-semibold leading-[0.9] tracking-[-0.023em]"
            >
              We Move
              <br />
              Businesses
              <br />
              Forward.
            </h2>
            <p data-reveal className="mt-6 max-w-[28rem] text-[17.5px] leading-[1.65] text-ink/80 sm:text-[19px]">
              {SERVICES_INTRO.lead}
            </p>

            <nav aria-label="Service areas" className="relative mt-12 hidden md:block">
              <span className="absolute left-[5px] top-2 h-[calc(100%-16px)] w-px bg-ink/15" />
              <span
                className="absolute left-0 top-[9px] h-[11px] w-[11px] rounded-full bg-ink shadow-[0_0_0_4px_#fff] transition-transform duration-700 ease-[cubic-bezier(0.65,0,0.35,1)]"
                style={{ transform: `translateY(${active * 40}px)` }}
              />
              <ol>
                {SERVICES.map((s, i) => (
                  <li key={s.n}>
                    <a
                      href={`#service-${i + 1}`}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToId(`service-${i + 1}`, -110);
                      }}
                      className={`flex h-10 items-center gap-4 pl-8 text-[15px] font-medium transition-colors ${
                        i === active ? 'text-ink' : 'text-ink/40 hover:text-ink/80'
                      }`}
                    >
                      <span className="font-mono text-[12.5px] tracking-[0.18em]">{s.n}</span>
                      {s.title}
                    </a>
                  </li>
                ))}
              </ol>
            </nav>
          </div>
        </div>

        {/* service articles */}
        <div className="md:col-span-7">
          {SERVICES.map((s, i) => (
            <article
              key={s.n}
              id={`service-${i + 1}`}
              className="group scroll-mt-28 border-t border-ink/15 py-12 first:border-t-0 first:pt-0 md:py-16"
            >
              <div data-reveal className="flex items-center gap-4 font-mono text-[13px] uppercase tracking-[0.22em] text-ink/50">
                <span className="text-ink">{s.n}</span>
                <span className="h-px flex-1 bg-ink/15">
                  <span className="block h-px w-0 bg-felt transition-[width] duration-700 group-hover:w-full" />
                </span>
                <span>Service</span>
              </div>
              <h3 data-reveal className="mt-6 text-[clamp(1.6rem,2.6vw,2.4rem)] font-semibold leading-[1.05] tracking-[-0.013em]">
                {s.title}
              </h3>
              <p data-reveal className="mt-2 text-[clamp(1.1rem,1.6vw,1.45rem)] font-medium tracking-[-0.007em] text-felt">
                {s.tagline}
              </p>
              <div data-reveal className="mt-5 max-w-[36rem] space-y-3 text-[17.5px] leading-[1.65] text-ink/80 sm:text-[18.5px]">
                {s.body.map((b) => (
                  <p key={b}>{b}</p>
                ))}
              </div>
              <ul data-reveal className="mt-8 grid border-t border-ink/10 sm:grid-cols-2 sm:gap-x-8">
                {s.items.map((it) => (
                  <li key={it} className="flex items-start gap-3 border-b border-ink/10 py-3.5 text-[16.5px] font-medium">
                    <span className="mt-[7px] h-[7px] w-[7px] shrink-0 rounded-full border border-ink/60" aria-hidden="true" />
                    {it}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
