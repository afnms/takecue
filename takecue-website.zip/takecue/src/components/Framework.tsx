import { useLayoutEffect, useRef, useState } from 'react';
import { FRAMEWORK_INTRO, STAGES } from '../content';
import { gsap, ScrollTrigger } from '../lib/gsap';
import { scrollToStage } from '../lib/scroll';
import { FRAMEWORK_STEP_VH } from '../lib/timeline';

function Intro({ className = '' }: { className?: string }) {
  return (
    <div className={className}>
      <p className="kicker" data-fw-reveal>
        <span className="text-paper/40">04</span> — {FRAMEWORK_INTRO.kicker}
      </p>
      <h2
        id="fw-title"
        data-fw-reveal
        className="mt-4 text-[clamp(2.6rem,6.4vw,6.6rem)] font-semibold leading-[0.88] tracking-[-0.023em]"
      >
        THE 8D
        <br />
        FRAMEWORK.
      </h2>
      <p data-fw-reveal className="mt-5 text-[clamp(1.05rem,1.6vw,1.4rem)] font-medium tracking-[-0.005em] text-paper">
        {FRAMEWORK_INTRO.subtitle}
      </p>
      <p data-fw-reveal className="mt-4 max-w-[34rem] text-[16.5px] leading-[1.65] text-paper/80 sm:text-[18px]">
        {FRAMEWORK_INTRO.lead}
      </p>
    </div>
  );
}

export function Framework() {
  const root = useRef<HTMLElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const activeRef = useRef(0);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('[data-fw-reveal]', {
        autoAlpha: 0,
        y: 40,
        stagger: 0.08,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: '[data-fw-intro]', start: 'top 70%' },
      });
      ScrollTrigger.create({
        trigger: '#framework-track',
        start: 'top top',
        end: 'bottom bottom',
        onUpdate: (s) => {
          const i = Math.min(STAGES.length - 1, Math.floor(s.progress * STAGES.length));
          if (i !== activeRef.current) {
            activeRef.current = i;
            setActive(i);
          }
        },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  useLayoutEffect(() => {
    if (!panel.current) return;
    gsap.fromTo(
      panel.current.querySelectorAll('[data-swap]'),
      { autoAlpha: 0, y: 26 },
      { autoAlpha: 1, y: 0, duration: 0.6, stagger: 0.05, ease: 'power3.out', overwrite: true },
    );
  }, [active]);

  const stage = STAGES[active];
  const trackHeight = `calc(100vh + ${STAGES.length * FRAMEWORK_STEP_VH}vh)`;

  return (
    <section id="framework" ref={root} className="relative" aria-labelledby="fw-title">
      {/* Intro scrolls in beside the eight ball */}
      <div data-fw-intro className="relative flex min-h-[100svh] items-end md:items-center">
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_top,rgba(17,17,17,0.96)_45%,transparent_75%)] md:bg-[linear-gradient(to_left,rgba(17,17,17,0.94)_36%,rgba(17,17,17,0.5)_56%,transparent_70%)]" />
        <div className="hero-pad-x relative mx-auto w-full max-w-[1440px] pb-14 md:pb-0">
          <Intro className="md:ml-[52%] md:max-w-[38rem]" />
        </div>
      </div>

      <div id="framework-track" className="relative" style={{ height: trackHeight }}>
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_top,rgba(17,17,17,0.98)_50%,rgba(17,17,17,0.4)_66%,transparent_78%)] md:bg-[linear-gradient(to_left,rgba(17,17,17,0.95)_38%,rgba(17,17,17,0.45)_56%,transparent_68%)]" />
          <div className="hero-pad-x relative mx-auto flex h-full max-w-[1440px] items-end pb-8 md:items-center md:pb-0">
            <div className="w-full md:ml-[50%] md:grid md:grid-cols-[11rem_1fr] md:gap-10 lg:grid-cols-[13rem_1fr]">
              {/* stage list (desktop) */}
              <ol className="hidden border-l border-white/10 md:block" aria-label="The eight dimensions">
                {STAGES.map((s, i) => (
                  <li key={s.n}>
                    <button
                      type="button"
                      onClick={() => scrollToStage(i)}
                      aria-current={i === active ? 'step' : undefined}
                      className={`group relative flex w-full items-baseline gap-3 py-2 pl-5 text-left transition-colors duration-300 ${
                        i === active ? 'text-paper' : i < active ? 'text-paper/55' : 'text-paper/30 hover:text-paper/80'
                      }`}
                    >
                      <span
                        className={`absolute -left-px top-0 h-full w-px transition-all duration-500 ${
                          i === active ? 'bg-paper' : i < active ? 'bg-[#3c7a55]' : 'bg-transparent'
                        }`}
                      />
                      <span className="font-mono text-[12px] tracking-[0.2em]">{s.n}</span>
                      <span className="text-[13.5px] font-semibold tracking-[0.2em]">{s.name}</span>
                    </button>
                  </li>
                ))}
              </ol>

              {/* active stage */}
              <div ref={panel} aria-live="polite">
                <div className="flex items-center justify-between font-mono text-[12px] uppercase tracking-[0.3em] text-paper/50">
                  <span>The 8D Framework</span>
                  <span>
                    <span className="text-paper">{stage.n}</span> / 08
                  </span>
                </div>
                <div className="mt-6 flex items-end gap-4 md:mt-10">
                  <span data-swap className="outline-num font-semibold leading-[0.8] tracking-[-0.027em] text-[clamp(4.2rem,9vw,8.5rem)]">
                    {stage.n}
                  </span>
                </div>
                <h3 data-swap className="mt-3 text-[clamp(2.3rem,5vw,4.8rem)] font-semibold leading-[0.9] tracking-[-0.02em]">
                  {stage.name}
                </h3>
                <p data-swap className="mt-3 font-mono text-[13px] uppercase tracking-[0.3em] text-[#6fa585]">
                  {stage.verb}
                </p>
                <p data-swap className="mt-5 max-w-[30rem] text-[17px] leading-[1.6] text-paper/80 sm:text-[19px]">
                  {stage.body}
                </p>

                {/* segmented progress — doubles as stage navigation */}
                <div className="mt-8 grid grid-cols-8 gap-1.5 md:mt-12" role="group" aria-label="Choose a dimension">
                  {STAGES.map((s, i) => (
                    <button
                      key={s.n}
                      type="button"
                      onClick={() => scrollToStage(i)}
                      aria-label={`${s.n} ${s.name} — ${s.verb}`}
                      className="group py-2"
                    >
                      <span
                        className={`block h-[3px] rounded-full transition-colors duration-500 ${
                          i === active ? 'bg-paper' : i < active ? 'bg-[#3c7a55]' : 'bg-white/15 group-hover:bg-white/40'
                        }`}
                      />
                      <span className={`mt-2 block font-mono text-[11.5px] tracking-[0.15em] ${i === active ? 'text-paper' : 'text-paper/40'}`}>
                        {s.n}
                      </span>
                    </button>
                  ))}
                </div>
                <p
                  className={`mt-6 text-[15px] font-medium tracking-[-0.002em] transition-colors duration-700 sm:text-[17px] md:mt-8 ${
                    active === STAGES.length - 1 ? 'text-paper' : 'text-paper/35'
                  }`}
                >
                  {FRAMEWORK_INTRO.closing}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/** Reduced-motion: every dimension visible at once. */
export function FrameworkStatic() {
  return (
    <section id="framework" className="relative bg-ink py-28 md:py-40" aria-labelledby="fw-title">
      <div id="framework-track" className="hero-pad-x mx-auto max-w-[1440px]">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <Intro />
            <div className="mt-12 flex h-40 w-40 items-center justify-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#4a4a4a_0%,#111_45%,#000_100%)] shadow-[0_40px_80px_-30px_rgba(0,0,0,1)]" aria-hidden="true">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-paper text-4xl font-semibold text-ink">8</span>
            </div>
          </div>
          <ol className="grid gap-px overflow-hidden rounded-2xl bg-white/10 sm:grid-cols-2 md:col-span-7">
            {STAGES.map((s) => (
              <li key={s.n} id={`stage-${Number(s.n)}`} className="bg-ink p-7">
                <span className="font-mono text-[13px] tracking-[0.2em] text-paper/45">{s.n}</span>
                <h3 className="mt-3 text-2xl font-semibold tracking-[-0.009em]">{s.name}</h3>
                <p className="mt-1 font-mono text-[12.5px] uppercase tracking-[0.28em] text-[#6fa585]">{s.verb}</p>
                <p className="mt-4 text-[17px] leading-relaxed text-paper/80">{s.body}</p>
              </li>
            ))}
          </ol>
        </div>
        <p className="mt-12 text-lg font-medium">{FRAMEWORK_INTRO.closing}</p>
      </div>
    </section>
  );
}
