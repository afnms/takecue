import { CUE_LOCKUP, CUE_MARK } from './logoPaths';

type P = { className?: string };

export const WhatsAppIcon = ({ className = 'h-5 w-5' }: P) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className} aria-hidden="true">
    <path
      strokeLinejoin="round"
      d="M3.6 20.4l1.2-4.3A8.6 8.6 0 1 1 8 19.3l-4.4 1.1z"
    />
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M9.2 8.2c.2-.4.4-.4.7-.4h.5c.2 0 .4 0 .5.4l.7 1.6c.1.2 0 .5-.1.6l-.5.6c-.1.1-.1.3 0 .5.6 1 1.4 1.8 2.5 2.4.2.1.4.1.5-.1l.6-.6c.2-.2.4-.2.6-.1l1.6.7c.3.1.4.3.4.5 0 .6-.2 1.3-.8 1.6-.6.4-1.6.6-3.4-.2-2-.9-3.6-2.6-4.4-4.4-.6-1.4-.4-2.4.1-3.1z"
    />
  </svg>
);

export const MailIcon = ({ className = 'h-5 w-5' }: P) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className} aria-hidden="true">
    <rect x="3" y="5" width="18" height="14" rx="1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.5 6l8.5 7 8.5-7" />
  </svg>
);

export const InstagramIcon = ({ className = 'h-5 w-5' }: P) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className} aria-hidden="true">
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.2" cy="6.8" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

export const ArrowIcon = ({ className = 'h-4 w-4' }: P) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={className} aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

export const ArrowUpRight = ({ className = 'h-4 w-4' }: P) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={className} aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" d="M7 17L17 7M8 7h9v9" />
  </svg>
);

/** Official CUE mark. Inherits colour from `currentColor`. */
export const Logo = ({ className = 'h-[22px] w-auto' }: P) => (
  <svg viewBox={CUE_MARK.viewBox} className={className} fill="currentColor" aria-hidden="true">
    <path d={CUE_MARK.d} />
  </svg>
);

/** Mark with the "Take The Cue" signature line. */
export const LogoLockup = ({ className = 'h-20 w-auto' }: P) => (
  <svg viewBox={CUE_LOCKUP.viewBox} className={className} fill="currentColor" aria-hidden="true">
    <path d={CUE_LOCKUP.d} />
  </svg>
);
