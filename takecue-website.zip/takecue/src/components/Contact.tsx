import { useEffect, useRef } from 'react';
import { CONNECT, CONTACT } from '../content';
import { useReveal } from '../lib/useReveal';
import type { EightBallMini } from '../three/EightBallMini';
import { ArrowUpRight, InstagramIcon, MailIcon, WhatsAppIcon } from './Icons';

const CHANNELS = [
  { ...CONTACT.whatsapp, Icon: WhatsAppIcon, external: true },
  { ...CONTACT.email, Icon: MailIcon, external: false },
  { ...CONTACT.instagram, Icon: InstagramIcon, external: true },
];

function BallCanvas({ reduced }: { reduced: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current!;
    let mini: EightBallMini | null = null;
    let disposed = false;
    let io: IntersectionObserver | null = null;
    const onResize = () => mini?.resize();
    // Only build the scene when the visitor is approaching it.
    const pre = new IntersectionObserver(
      async ([e]) => {
        if (!e.isIntersecting) return;
        pre.disconnect();
        try {
          const { EightBallMini } = await import('../three/EightBallMini');
          if (disposed) return;
          mini = new EightBallMini(canvas, reduced);
        } catch {
          return;
        }
        canvas.style.opacity = '1';
        window.addEventListener('resize', onResize);
        io = new IntersectionObserver(([en]) => mini?.setRunning(en.isIntersecting));
        io.observe(canvas);
      },
      { rootMargin: '600px 0px' },
    );
    pre.observe(canvas);
    return () => {
      disposed = true;
      pre.disconnect();
      io?.disconnect();
      window.removeEventListener('resize', onResize);
      mini?.dispose();
    };
  }, [reduced]);
  return (
    <div className="relative aspect-square w-full" aria-hidden="true">
      <span className="absolute bottom-[6%] left-1/2 h-[9%] w-[58%] -translate-x-1/2 rounded-[50%] bg-black/45 blur-2xl" />
      <canvas ref={ref} className="relative h-full w-full opacity-0 transition-opacity duration-1000" />
    </div>
  );
}

export function Contact({ reduced }: { reduced: boolean }) {
  const root = useRef<HTMLElement>(null);
  useReveal(root, reduced);
  return (
    <section id="contact" ref={root} className="relative overflow-hidden bg-felt" aria-labelledby="contact-title">
      <div className="grain pointer-events-none absolute inset-0 opacity-[0.08] mix-blend-overlay" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_75%_40%,rgba(255,255,255,0.07),transparent_70%)]" />
      <div className="hero-pad-x relative mx-auto max-w-[1440px] py-24 md:py-36">
        <p className="kicker" data-reveal>
          <span className="text-paper/50">08</span> — {CONNECT.kicker}
        </p>
        <div className="mt-6 grid items-center gap-10 md:grid-cols-12">
          <h2 id="contact-title" className="font-semibold uppercase leading-[0.88] tracking-[-0.023em] md:col-span-8">
            <span data-reveal className="block text-[clamp(2.5rem,6.6vw,7rem)]">Your Next Move</span>
            <span data-reveal data-delay="0.06" className="block text-[clamp(2.5rem,6.6vw,7rem)]">Starts Here.</span>
            <span data-reveal data-delay="0.12" className="mt-5 block text-[clamp(1.35rem,3vw,3rem)] tracking-[-0.016em] text-paper/60">
              Let's Take Your Business Beyond.
            </span>
          </h2>
          <div data-reveal className="mx-auto w-[62%] max-w-[420px] md:col-span-4 md:w-full">
            <BallCanvas reduced={reduced} />
          </div>
        </div>

        <div className="mt-14 grid gap-12 border-t border-white/15 pt-12 md:mt-20 md:grid-cols-12 md:gap-10">
          <div className="md:col-span-4">
            <p data-reveal className="text-[clamp(1.5rem,2.4vw,2.2rem)] font-semibold tracking-[-0.013em]">
              {CONNECT.talk}
            </p>
            <p data-reveal className="mt-4 max-w-[26rem] text-[17.5px] leading-[1.65] text-paper/85 sm:text-[19px]">
              {CONNECT.lead}
            </p>
          </div>
          <ul className="md:col-span-7 md:col-start-6">
            {CHANNELS.map(({ label, display, href, Icon, external }, i) => (
              <li key={label} data-reveal data-delay={String(i * 0.06)}>
                <a
                  href={href}
                  {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                  className="group flex items-center gap-5 border-b border-white/15 py-6 transition-colors first:pt-0 hover:border-paper sm:gap-7"
                >
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-white/25 transition-colors duration-300 group-hover:border-paper group-hover:bg-paper group-hover:text-ink">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-mono text-[12.5px] uppercase tracking-[0.28em] text-paper/60">{label}</span>
                    <span className="mt-1 block truncate text-[clamp(1.2rem,2.6vw,2.2rem)] font-medium tracking-[-0.009em]">
                      {display}
                    </span>
                  </span>
                  <ArrowUpRight className="h-6 w-6 shrink-0 text-paper/50 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-paper" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
