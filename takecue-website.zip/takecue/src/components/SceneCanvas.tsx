import { useEffect, useRef, useState } from 'react';
import { ScrollTrigger } from '../lib/gsap';
import { scrollToStage } from '../lib/scroll';
import type { BilliardEngine } from '../three/BilliardEngine';

type Props = { reduced: boolean };

const pickQuality = () => {
  const forced = new URLSearchParams(location.search).get('quality');
  if (forced === 'high' || forced === 'low') return forced;
  const narrow = window.matchMedia('(max-width: 820px)').matches;
  const cores = navigator.hardwareConcurrency || 4;
  return narrow || cores <= 4 ? 'low' : 'high';
};

/**
 * The fixed WebGL stage behind the story and the 8D Framework.
 * In reduced-motion mode it renders a single composed poster frame instead.
 */
export function SceneCanvas({ reduced }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    let engine: BilliardEngine | null = null;
    let disposed = false;
    const triggers: ScrollTrigger[] = [];
    let resizeTimer = 0;
    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => engine?.resize(), 120);
    };

    (async () => {
      // Fetch the 3D engine in parallel with the fonts it prints onto the ball.
      const enginePromise = import('../three/BilliardEngine');
      try {
        await Promise.race([
          Promise.all([
            document.fonts.load('700 100px "Cormorant Garamond"'),
            document.fonts.load('600 64px "Cormorant Garamond"'),
          ]),
          new Promise((r) => setTimeout(r, 1500)),
        ]);
      } catch {
        /* fonts are a nicety for the ball print */
      }
      const { BilliardEngine } = await enginePromise;
      if (disposed) return;
      try {
        engine = new BilliardEngine(canvas, {
          quality: pickQuality(),
          reduced,
          onStageSelect: reduced ? undefined : scrollToStage,
        });
      } catch (err) {
        console.warn('WebGL unavailable, using static fallback', err);
        setFailed(true);
        return;
      }
      window.addEventListener('resize', onResize);
      if (import.meta.env.DEV || new URLSearchParams(location.search).has('debug')) (window as unknown as { __engine: unknown }).__engine = engine;
      if (!reduced) {
        const story = ScrollTrigger.create({
          trigger: '#story',
          start: 'top top',
          end: 'bottom bottom',
          onUpdate: (s) => engine?.setStoryProgress(s.progress),
        });
        const fw = ScrollTrigger.create({
          trigger: '#framework-track',
          start: 'top top',
          end: 'bottom bottom',
          onUpdate: (s) => engine?.setFrameworkProgress(s.progress),
          onEnter: () => engine?.setFrameworkVisible(true),
          onEnterBack: () => engine?.setFrameworkVisible(true),
          onLeaveBack: () => engine?.setFrameworkVisible(false),
        });
        const cover = ScrollTrigger.create({
          trigger: '#services',
          start: 'top top',
          onEnter: () => {
            engine?.setRunning(false);
            wrap.style.visibility = 'hidden';
          },
          onLeaveBack: () => {
            wrap.style.visibility = 'visible';
            engine?.setRunning(true);
          },
        });
        triggers.push(story, fw, cover);
        engine.setStoryProgress(story.progress);
        engine.setFrameworkProgress(fw.progress);
        engine.setFrameworkVisible(fw.progress > 0);
        const covered = cover.progress > 0 || window.scrollY > cover.start;
        wrap.style.visibility = covered ? 'hidden' : 'visible';
        engine.setRunning(!covered);
      }
      setReady(true);
    })();

    return () => {
      disposed = true;
      window.removeEventListener('resize', onResize);
      triggers.forEach((t) => t.kill());
      engine?.dispose();
    };
  }, [reduced]);

  return (
    <div
      ref={wrapRef}
      aria-hidden="true"
      className={`${reduced ? 'absolute' : 'fixed'} inset-0 z-0 overflow-hidden bg-ink`}
    >
      <canvas
        ref={canvasRef}
        className={`block h-full w-full transition-opacity duration-[1600ms] ease-out ${ready ? 'opacity-100' : 'opacity-0'}`}
      />
      {failed && <FallbackBalls />}
            {/* Grain, grade and lens vignette are rendered in WebGL; this only keeps the frame edges calm for type. */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_85%_at_50%_45%,transparent_55%,rgba(10,10,10,0.5)_100%)]" />
    </div>
  );
}

function FallbackBalls() {
  return (
    <div className="absolute inset-0 flex items-center justify-center gap-[6vmin] bg-[radial-gradient(60%_50%_at_50%_55%,#1E402B_0%,#111_70%)]">
      <span className="h-[18vmin] w-[18vmin] rounded-full bg-[radial-gradient(circle_at_35%_30%,#fff_0%,#e9e7e1_45%,#9a9893_100%)] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)]" />
      <span className="relative flex h-[18vmin] w-[18vmin] items-center justify-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#444_0%,#111_45%,#000_100%)] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)]">
        <span className="flex h-[8vmin] w-[8vmin] items-center justify-center rounded-full bg-paper text-[5vmin] font-semibold text-ink">8</span>
      </span>
    </div>
  );
}
