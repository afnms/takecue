import { useRef } from 'react';
import { WHY, WHY_INTRO } from '../content';
import { useReveal } from '../lib/useReveal';

const stroke = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.2, pathLength: 1, strokeDasharray: 1, vectorEffect: 'non-scaling-stroke' as const };

/** Minimal geometric diagrams — angles and trajectories, not icons. */
const DIAGRAMS = [
  // Strategic Perspective — a view that takes in the whole table
  <svg key="0" viewBox="0 0 160 96" className="h-24 w-40" aria-hidden="true">
    <rect x="44" y="14" width="108" height="68" rx="6" {...stroke} data-draw="" />
    <path d="M10 48 L44 14 M10 48 L152 14 M10 48 L152 82 M10 48 L44 82" {...stroke} strokeOpacity="0.45" data-draw="" data-delay="0.2" />
    <circle cx="10" cy="48" r="4" fill="#fff" />
    <circle cx="112" cy="46" r="5" fill="#3c7a55" />
  </svg>,
  // Integrated Thinking — five disciplines meeting in one direction
  <svg key="1" viewBox="0 0 160 96" className="h-24 w-40" aria-hidden="true">
    <path d="M18 14 L96 48 M18 31 L96 48 M18 48 L96 48 M18 65 L96 48 M18 82 L96 48 M96 48 L150 48" {...stroke} data-draw="" />
    {[14, 31, 48, 65, 82].map((y) => (
      <circle key={y} cx="18" cy={y} r="3.2" fill="#fff" />
    ))}
    <circle cx="150" cy="48" r="5" fill="#3c7a55" />
  </svg>,
  // Action-Oriented — the plan (dashed) becomes the move (solid)
  <svg key="2" viewBox="0 0 160 96" className="h-24 w-40" aria-hidden="true">
    <path d="M14 70 L74 40" fill="none" stroke="currentColor" strokeOpacity="0.5" strokeWidth="1.2" strokeDasharray="3 5" />
    <path d="M74 40 L146 22" {...stroke} data-draw="" data-delay="0.2" />
    <circle cx="14" cy="70" r="5" fill="#fff" />
    <circle cx="74" cy="40" r="3" fill="none" stroke="#fff" strokeWidth="1.2" />
    <circle cx="146" cy="22" r="5" fill="#3c7a55" />
  </svg>,
  // Growth with Purpose — measured steps, one direction
  <svg key="3" viewBox="0 0 160 96" className="h-24 w-40" aria-hidden="true">
    <path d="M12 84 L48 84 L48 62 L84 62 L84 40 L120 40 L120 18 L150 18" {...stroke} data-draw="" />
    <circle cx="12" cy="84" r="4" fill="#fff" />
    <circle cx="150" cy="18" r="5" fill="#3c7a55" />
  </svg>,
];

export function Why({ reduced }: { reduced: boolean }) {
  const root = useRef<HTMLElement>(null);
  useReveal(root, reduced);
  return (
    <section id="why" ref={root} className="relative border-t border-white/10 bg-ink" aria-labelledby="why-title">
      <div className="hero-pad-x mx-auto max-w-[1440px] py-24 md:py-36">
        <p className="kicker" data-reveal>
          <span className="text-paper/40">06</span> — {WHY_INTRO.kicker}
        </p>
        <h2 id="why-title" className="mt-5 text-[clamp(2.2rem,5.2vw,5.6rem)] font-semibold leading-[0.95] tracking-[-0.023em]">
          <span data-reveal className="block text-paper/40">The Right Perspective.</span>
          <span data-reveal data-delay="0.08" className="block text-paper/80">The Right Direction.</span>
          <span data-reveal data-delay="0.16" className="block">The Right Move.</span>
        </h2>

        <ol className="mt-16 grid gap-px overflow-hidden rounded-[28px] bg-white/10 sm:grid-cols-2 md:mt-24 lg:grid-cols-4">
          {WHY.map((w, i) => (
            <li key={w.title} data-reveal data-delay={String(i * 0.08)} className="flex flex-col bg-ink p-7 sm:p-9">
              <div className="text-paper/80">{DIAGRAMS[i]}</div>
              <span className="mt-10 font-mono text-[13px] tracking-[0.22em] text-paper/40">{String(i + 1).padStart(2, '0')}</span>
              <h3 className="mt-3 text-[1.45rem] font-semibold leading-[1.1] tracking-[-0.009em]">{w.title}</h3>
              <p className="mt-4 text-[17px] leading-[1.6] text-paper/80">{w.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
