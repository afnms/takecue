import { useLayoutEffect, useRef } from 'react';
import { ABOUT, CONTACT, HERO } from '../content';
import { gsap } from '../lib/gsap';
import { scrollToId } from '../lib/scroll';
import { STORY, STORY_VH } from '../lib/timeline';
import { ArrowIcon } from './Icons';

const SCENES = [
  { at: 0, label: 'The Starting Point' },
  { at: 0.12, label: 'The Right Direction' },
  { at: 0.44, label: 'The Strategic Move' },
  { at: 0.72, label: 'The Eight Dimensions' },
];

/** Scroll position (fraction of story) where "Who We Are" is fully on stage. */
const ABOUT_ANCHOR = 0.24;

export function Story() {
  const root = useRef<HTMLElement>(null);
  const sceneNum = useRef<HTMLSpanElement>(null);
  const sceneLabel = useRef<HTMLSpanElement>(null);
  const sceneBar = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Load-in for the opening frame (independent of scroll).
      gsap.from('[data-intro]', {
        yPercent: 110,
        duration: 1.5,
        ease: 'expo.out',
        stagger: 0.09,
        delay: 0.35,
      });
      gsap.from('[data-intro-fade]', { autoAlpha: 0, y: 16, duration: 1.2, ease: 'power3.out', stagger: 0.08, delay: 0.9 });

      let lastScene = -1;
      const tl = gsap.timeline({
        defaults: { ease: 'none' },
        scrollTrigger: {
          trigger: root.current,
          start: 'top top',
          end: 'bottom bottom',
          scrub: true,
          onUpdate: (s) => {
            const p = s.progress;
            let idx = 0;
            SCENES.forEach((sc, i) => p >= sc.at && (idx = i));
            if (idx !== lastScene && sceneNum.current && sceneLabel.current) {
              lastScene = idx;
              sceneNum.current.textContent = String(idx + 1).padStart(2, '0');
              sceneLabel.current.textContent = SCENES[idx].label;
            }
            if (sceneBar.current) sceneBar.current.style.transform = `scaleX(${p})`;
          },
        },
      });
      tl.set({}, {}, 1); // timeline spans exactly the story (0 → 1)

      const [h0, h1] = STORY.heroOut;
      tl.to('[data-hero]', { autoAlpha: 0, y: -70, duration: h1 - h0 }, h0);
      tl.to('[data-hint]', { autoAlpha: 0, duration: 0.03 }, 0.02);
      tl.fromTo('[data-indicator]', { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.03 }, h1);

      const mm = gsap.matchMedia();
      mm.add(
        {
          compact: '(max-width: 640px) and (max-height: 820px)',
          roomy: 'not ((max-width: 640px) and (max-height: 820px))',
        },
        (c) => {
          const compact = c.conditions?.compact;
          const [a0] = STORY.aboutIn;
          tl.fromTo('[data-about-scrim]', { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.05 }, a0 - 0.02);
          tl.fromTo('[data-about-a]', { autoAlpha: 0, y: 36 }, { autoAlpha: 1, y: 0, duration: 0.045, stagger: 0.012 }, a0);
          if (compact) {
            tl.to('[data-group-a]', { autoAlpha: 0, y: -24, duration: 0.03 }, 0.265);
            tl.fromTo('[data-about-b]', { autoAlpha: 0, y: 36 }, { autoAlpha: 1, y: 0, duration: 0.04, stagger: 0.012 }, 0.29);
          } else {
            tl.fromTo('[data-about-b]', { autoAlpha: 0, y: 36 }, { autoAlpha: 1, y: 0, duration: 0.045, stagger: 0.012 }, a0 + 0.05);
          }
          const [o0, o1] = STORY.aboutOut;
          tl.to('[data-about]', { autoAlpha: 0, y: -50, duration: o1 - o0 }, o0);
          tl.to('[data-about-scrim]', { autoAlpha: 0, duration: o1 - o0 }, o0);
        },
      );

      tl.fromTo('[data-cap3]', { autoAlpha: 0, y: 40 }, { autoAlpha: 1, y: 0, duration: 0.04 }, 0.47);
      tl.to('[data-cap3]', { autoAlpha: 0, y: -30, duration: 0.035 }, 0.585);
      tl.fromTo('[data-cap4]', { autoAlpha: 0, y: 30 }, { autoAlpha: 1, y: 0, duration: 0.04 }, 0.74);
      tl.to('[data-cap4]', { autoAlpha: 0, duration: 0.04 }, 0.9);
      tl.fromTo('[data-eight]', { autoAlpha: 0, scale: 0.86 }, { autoAlpha: 1, scale: 1, duration: 0.12, ease: 'power2.out' }, 0.84);
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="story"
      ref={root}
      aria-label="Introduction"
      className="relative"
      style={{ height: `${STORY_VH}vh` }}
    >
      <div id="home" className="absolute left-0 top-0 h-px w-px" />
      <div
        id="about"
        className="absolute left-0 h-px w-px"
        style={{ top: `${ABOUT_ANCHOR * (STORY_VH - 100)}vh` }}
      />

      <div className="sticky top-0 h-[100svh] overflow-hidden">
        {/* ---------- SCENE 01 · HERO: type layer (difference-blended over the ball) ---------- */}
        <div data-hero className="hero-type pointer-events-none absolute inset-0">
          <div className="hero-pad relative mx-auto flex h-full max-w-[1440px] flex-col pb-[136px] min-[420px]:pb-[92px] sm:pb-[104px]">
            <p className="mb-4 overflow-hidden font-mono text-[12px] uppercase tracking-[0.32em] text-paper/80 sm:mb-5 sm:text-[13px]">
              <span data-intro className="inline-block">{HERO.category}</span>
            </p>
            <h1 className="flex flex-1 flex-col justify-between font-semibold uppercase leading-[0.84] tracking-tightest text-paper">
              <span className="block text-[clamp(3.1rem,10.4vw,11.5rem)]">
                <span className="block overflow-hidden pb-[0.05em]">
                  <span data-intro className="block">Take the</span>
                </span>
                <span className="block overflow-hidden pb-[0.05em]">
                  <span data-intro className="block">Cue.</span>
                </span>
              </span>
              <span className="block text-right text-[clamp(1.9rem,5.6vw,6.2rem)]">
                <span className="block overflow-hidden pb-[0.05em]">
                  <span data-intro className="block">From Building</span>
                </span>
                <span className="block overflow-hidden pb-[0.05em]">
                  <span data-intro className="block">to Beyond.</span>
                </span>
              </span>
            </h1>
            <div className="mt-5 max-w-[23rem] md:absolute md:bottom-[104px] md:left-[var(--pad)] md:mt-0">
              <p data-intro-fade className="text-[16.5px] font-medium leading-snug text-paper sm:text-base">
                {HERO.statement}
              </p>
              <p data-intro-fade className="mt-1.5 text-[15.5px] leading-snug text-paper/80 sm:text-[17px]">
                {HERO.lead}
              </p>
            </div>
          </div>
        </div>
        {/* hero: interactive layer */}
        <div data-hero className="absolute inset-x-0 bottom-0">
          <div className="hero-pad-x mx-auto flex max-w-[1440px] items-end justify-between pb-6 sm:pb-8">
            <div data-intro-fade className="flex flex-wrap gap-2.5">
              <a
                href="#framework"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToId('framework');
                }}
                className="btn-primary"
              >
                {HERO.ctaPrimary}
                <ArrowIcon />
              </a>
              <a href={CONTACT.whatsapp.href} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                {HERO.ctaSecondary}
              </a>
            </div>
            <div data-hint className="hidden items-center gap-3 font-mono text-[12px] uppercase tracking-[0.3em] text-paper/55 md:flex">
              <span className="relative block h-10 w-px overflow-hidden bg-paper/15">
                <span className="scroll-tick absolute inset-x-0 top-0 h-4 bg-paper" />
              </span>
              Scroll to take the shot
            </div>
          </div>
        </div>

        {/* ---------- SCENE 02 · WHO WE ARE ---------- */}
        <div
          data-about-scrim
          className="pointer-events-none invisible absolute inset-0 bg-[linear-gradient(to_top,rgba(17,17,17,0.97)_48%,rgba(17,17,17,0.6)_68%,transparent_86%)] opacity-0 md:bg-[linear-gradient(to_left,rgba(17,17,17,0.95)_30%,rgba(17,17,17,0.55)_50%,transparent_66%)]"
        />
        <div data-about className="absolute inset-0 flex items-end md:items-center">
          <div className="hero-pad-x mx-auto w-full max-w-[1440px] pb-8 md:pb-0">
            <div className="about-stack max-w-[34rem] md:ml-auto md:mr-[2vw]">
              <div data-group-a>
                <p data-about-a className="kicker invisible">
                  <span className="text-paper/40">02</span> — {ABOUT.kicker}
                </p>
                <h2 data-about-a className="invisible mt-4 text-[clamp(2.1rem,4.6vw,4.4rem)] font-semibold leading-[0.95] tracking-[-0.018em]">
                  Beyond Ideas.
                  <br />
                  <span className="text-paper/45">Into Business.</span>
                </h2>
                <div className="mt-6 space-y-4 text-[16.5px] leading-[1.6] text-paper/85 sm:text-[18px] md:mt-8">
                  <p data-about-a className="invisible">{ABOUT.paragraphs[0]}</p>
                  <p data-about-a className="invisible">{ABOUT.paragraphs[1]}</p>
                </div>
              </div>
              <div data-group-b className="mt-4 space-y-4 text-[16.5px] leading-[1.6] text-paper/85 sm:text-[18px]">
                <p data-about-b className="invisible">{ABOUT.paragraphs[2]}</p>
                <p data-about-b className="invisible flex gap-3 border-l-2 border-[#3c7a55] pl-4 text-[17.5px] font-medium leading-snug text-paper sm:text-[20px]">
                  {ABOUT.closing}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ---------- SCENE 03 · THE STRATEGIC MOVE ---------- */}
        <div data-cap3 className="pointer-events-none invisible absolute inset-x-0 bottom-0 h-[45%] bg-gradient-to-t from-ink/80 to-transparent" />
        <div data-cap3 className="invisible absolute inset-x-0 bottom-[9vh] text-center">
          <p className="kicker justify-center">
            <span className="text-paper/40">03</span> — The Strategic Move
          </p>
          <p className="mx-auto mt-4 max-w-[16ch] px-6 text-[clamp(2rem,5vw,4.6rem)] font-semibold leading-[0.95] tracking-[-0.02em]">
            In business, every move matters.
          </p>
        </div>

        {/* ---------- SCENE 04 · THE EIGHT DIMENSIONS ---------- */}
        <div data-cap4 className="invisible absolute inset-x-0 top-[16vh] text-center md:top-[18vh]">
          <p className="kicker justify-center">
            <span className="text-paper/40">04</span> — The Eight Dimensions
          </p>
        </div>
        <div
          data-eight
          className="pointer-events-none invisible absolute inset-0 flex items-end justify-center pb-[4vh] md:items-center md:justify-end md:pb-0 md:pr-[7vw]"
        >
          <span className="outline-8 select-none font-semibold leading-none tracking-[-0.027em] text-[48vh] md:text-[82vh]">8</span>
        </div>

        {/* ---------- scene indicator ---------- */}
        <div data-indicator className="pointer-events-none invisible absolute bottom-7 left-0 right-0 hidden lg:block">
          <div className="hero-pad-x mx-auto flex max-w-[1440px] justify-start">
            <div className="w-72 whitespace-nowrap font-mono text-[12px] uppercase tracking-[0.26em] text-paper/60">
              <div className="flex items-baseline justify-between gap-6">
                <span>
                  Scene <span ref={sceneNum}>01</span>
                </span>
                <span ref={sceneLabel} className="text-paper/90">
                  The Starting Point
                </span>
              </div>
              <span className="mt-2 block h-px w-full bg-paper/15">
                <span ref={sceneBar} className="block h-px w-full origin-left scale-x-0 bg-[#3c7a55]" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/** Reduced-motion introduction: same content, no pinning, a single poster frame. */
export function StoryStatic({ children }: { children?: React.ReactNode }) {
  return (
    <>
      <section id="story" className="relative min-h-[100svh] overflow-hidden" aria-label="Introduction">
        <div id="home" />
        {children}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
        <div className="hero-pad relative mx-auto flex min-h-[100svh] max-w-[1440px] flex-col justify-end pb-12">
          <p className="kicker">{HERO.category}</p>
          <h1 className="mt-5 text-[clamp(3rem,9vw,9.5rem)] font-semibold uppercase leading-[0.86] tracking-tightest">
            Take the Cue.
            <span className="mt-2 block text-[clamp(1.8rem,5vw,5.4rem)] text-paper/80">From Building to Beyond.</span>
          </h1>
          <p className="mt-8 max-w-md text-base font-medium">{HERO.statement}</p>
          <p className="mt-2 max-w-md text-paper/80">{HERO.lead}</p>
          <div className="mt-8 flex flex-wrap gap-2.5">
            <a href="#framework" onClick={(e) => { e.preventDefault(); scrollToId('framework'); }} className="btn-primary">
              {HERO.ctaPrimary}
              <ArrowIcon />
            </a>
            <a href={CONTACT.whatsapp.href} target="_blank" rel="noopener noreferrer" className="btn-ghost">
              {HERO.ctaSecondary}
            </a>
          </div>
        </div>
      </section>
      <section id="about" className="relative bg-ink py-28 md:py-40">
        <div className="hero-pad-x mx-auto grid max-w-[1440px] gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="kicker"><span className="text-paper/40">02</span> — {ABOUT.kicker}</p>
            <h2 className="mt-4 text-[clamp(2.2rem,4.6vw,4.4rem)] font-semibold leading-[0.95] tracking-[-0.018em]">
              Beyond Ideas.<br /><span className="text-paper/45">Into Business.</span>
            </h2>
          </div>
          <div className="space-y-5 text-[18px] leading-relaxed text-paper/85 md:col-span-6 md:col-start-7">
            {ABOUT.paragraphs.map((p) => <p key={p}>{p}</p>)}
            <p className="border-l-2 border-[#3c7a55] pl-4 text-lg font-medium text-paper">{ABOUT.closing}</p>
          </div>
        </div>
      </section>
    </>
  );
}
