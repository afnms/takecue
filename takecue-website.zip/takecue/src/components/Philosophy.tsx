import { useLayoutEffect, useRef } from 'react';
import { PHILOSOPHY } from '../content';
import { gsap } from '../lib/gsap';
import { useReveal } from '../lib/useReveal';

// Table geometry (viewBox 600 × 340). A one-cushion bank: the cue ball comes
// off the top rail at equal angles and cuts the eight into the corner pocket.
const START = { x: 130, y: 236 };
const BANK = { x: 300, y: 34 };
const EIGHT = { x: 420, y: 168 };
const POCKET = { x: 572, y: 304 };
const BALL_R = 11;
const toPocket = { x: POCKET.x - EIGHT.x, y: POCKET.y - EIGHT.y };
const tpLen = Math.hypot(toPocket.x, toPocket.y);
const CONTACT = {
  x: EIGHT.x - (toPocket.x / tpLen) * BALL_R * 2,
  y: EIGHT.y - (toPocket.y / tpLen) * BALL_R * 2,
};
const CUE_PATH = `M${START.x} ${START.y} L${BANK.x} ${BANK.y} L${CONTACT.x.toFixed(1)} ${CONTACT.y.toFixed(1)}`;
const EIGHT_PATH = `M${EIGHT.x} ${EIGHT.y} L${POCKET.x} ${POCKET.y}`;
const aim = { x: START.x - BANK.x, y: START.y - BANK.y };
const aimLen = Math.hypot(aim.x, aim.y);
const CUE_STICK = {
  x1: START.x + (aim.x / aimLen) * 18,
  y1: START.y + (aim.y / aimLen) * 18,
  x2: START.x + (aim.x / aimLen) * 150,
  y2: START.y + (aim.y / aimLen) * 150,
};

export function Philosophy({ reduced }: { reduced: boolean }) {
  const root = useRef<HTMLElement>(null);
  const cuePath = useRef<SVGPathElement>(null);
  const eightPath = useRef<SVGPathElement>(null);
  const cueBall = useRef<SVGGElement>(null);
  const eightBall = useRef<SVGGElement>(null);
  const stick = useRef<SVGLineElement>(null);
  useReveal(root, reduced);

  useLayoutEffect(() => {
    const cp = cuePath.current!;
    const ep = eightPath.current!;
    const cueLen = cp.getTotalLength();
    const eightLen = ep.getTotalLength();
    const place = (g: SVGGElement, path: SVGPathElement, len: number, t: number) => {
      const pt = path.getPointAtLength(len * t);
      g.setAttribute('transform', `translate(${pt.x} ${pt.y})`);
    };
    if (reduced) {
      place(cueBall.current!, cp, cueLen, 1);
      place(eightBall.current!, ep, eightLen, 0.9);
      return;
    }
    const state = { aim: 0, strike: 0, roll: 0, sink: 0 };
    const render = () => {
      // Planned line → strike → roll → sink.
      cp.style.strokeDashoffset = String(1 - state.aim);
      ep.style.strokeDashoffset = String(1 - state.sink);
      place(cueBall.current!, cp, cueLen, state.roll);
      place(eightBall.current!, ep, eightLen, state.sink);
      const back = 1 - state.strike;
      stick.current!.setAttribute(
        'transform',
        `translate(${(aim.x / aimLen) * 26 * back} ${(aim.y / aimLen) * 26 * back})`,
      );
      stick.current!.style.opacity = String(1 - state.roll * 1.6);
      eightBall.current!.style.opacity = String(1 - Math.max(0, state.sink - 0.85) / 0.15);
    };
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        defaults: { ease: 'none' },
        onUpdate: render,
        scrollTrigger: { trigger: '[data-table]', start: 'top 80%', end: 'bottom 35%', scrub: 0.6 },
      });
      tl.to(state, { aim: 1, duration: 0.3 })
        .to(state, { strike: 1, duration: 0.08, ease: 'power2.in' })
        .to(state, { roll: 1, duration: 0.36, ease: 'power1.out' })
        .to(state, { sink: 1, duration: 0.26, ease: 'power2.out' });
      render();
    }, root);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <section id="philosophy" ref={root} className="on-light relative overflow-hidden bg-paper text-ink" aria-labelledby="philosophy-title">
      <div className="hero-pad-x mx-auto max-w-[1440px] py-24 md:py-36">
        <p className="kicker-dark" data-reveal>
          <span className="text-ink/40">07</span> — {PHILOSOPHY.kicker}
        </p>
        <h2
          id="philosophy-title"
          data-reveal
          className="mt-5 text-[clamp(3rem,9.6vw,10.5rem)] font-semibold leading-[0.84] tracking-[-0.027em]"
        >
          Every Move
          <br />
          Matters.
        </h2>

        <div className="mt-14 grid items-center gap-14 md:mt-20 md:grid-cols-12 md:gap-10">
          <div className="md:col-span-5">
            <p data-reveal className="text-[clamp(1.3rem,2vw,1.75rem)] font-medium leading-[1.25] tracking-[-0.009em]">
              {PHILOSOPHY.lead}
            </p>
            <div className="mt-6 space-y-4 text-[17.5px] leading-[1.65] text-ink/80 sm:text-[19px]">
              {PHILOSOPHY.body.map((b) => (
                <p data-reveal key={b}>
                  {b}
                </p>
              ))}
            </div>
            <p data-reveal className="mt-10 inline-flex items-center gap-3 rounded-full bg-ink px-5 py-3 text-[13.5px] font-medium uppercase tracking-[0.2em] text-paper">
              <span className="h-2 w-2 rounded-full bg-paper" />
              {PHILOSOPHY.closing}
            </p>
          </div>

          <figure data-table className="md:col-span-7">
            <svg viewBox="0 0 600 340" className="h-auto w-full" role="img" aria-label="A bank shot: the cue ball comes off the top cushion and sends the eight ball into the corner pocket.">
              <defs>
                <radialGradient id="felt-light" cx="50%" cy="45%" r="70%">
                  <stop offset="0" stopColor="#2a573b" />
                  <stop offset="1" stopColor="#1E402B" />
                </radialGradient>
                <radialGradient id="cue-shade" cx="35%" cy="30%" r="75%">
                  <stop offset="0" stopColor="#fff" />
                  <stop offset="1" stopColor="#d9d8d3" />
                </radialGradient>
                <radialGradient id="eight-shade" cx="35%" cy="30%" r="75%">
                  <stop offset="0" stopColor="#4a4a4a" />
                  <stop offset="0.5" stopColor="#111" />
                </radialGradient>
              </defs>
              <rect x="0" y="0" width="600" height="340" rx="26" fill="#111" />
              <rect x="20" y="20" width="560" height="300" rx="10" fill="url(#felt-light)" />
              {[ [28, 28], [300, 22], [572, 28], [28, 312], [300, 318], [572, 312] ].map(([x, y]) => (
                <circle key={`${x}-${y}`} cx={x} cy={y} r="15" fill="#0a0a0a" />
              ))}
              {/* diamonds */}
              {[90, 160, 230, 370, 440, 510].map((x) => (
                <g key={x} fill="#fff" opacity="0.5">
                  <circle cx={x} cy="10" r="2" />
                  <circle cx={x} cy="330" r="2" />
                </g>
              ))}
              {/* head string + spot */}
              <line x1="160" y1="20" x2="160" y2="320" stroke="#fff" strokeOpacity="0.08" />
              <circle cx={EIGHT.x} cy={EIGHT.y} r={BALL_R + 4} fill="none" stroke="#fff" strokeOpacity="0.14" strokeDasharray="2 4" />

              {/* trajectories */}
              <path ref={cuePath} d={CUE_PATH} fill="none" stroke="#fff" strokeOpacity="0.75" strokeWidth="1.4" strokeDasharray="1" pathLength={1} />
              <path ref={eightPath} d={EIGHT_PATH} fill="none" stroke="#fff" strokeOpacity="0.4" strokeWidth="1.4" strokeDasharray="1" pathLength={1} />
              <text x={BANK.x} y={BANK.y + 80} textAnchor="middle" fill="#fff" fillOpacity="0.55" fontSize="8.5" fontFamily="Cormorant Garamond, serif" fontWeight="600" letterSpacing="1.6">
                THE RIGHT ANGLE
              </text>

              {/* cue stick */}
              <line ref={stick} x1={CUE_STICK.x1} y1={CUE_STICK.y1} x2={CUE_STICK.x2} y2={CUE_STICK.y2} stroke="#f4f3ef" strokeWidth="5" strokeLinecap="round" />

              {/* balls */}
              <g ref={eightBall} transform={`translate(${EIGHT.x} ${EIGHT.y})`}>
                <circle r={BALL_R} fill="url(#eight-shade)" />
                <circle r="4.6" fill="#fff" />
                <text y="2.6" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#111" fontFamily="Cormorant Garamond, serif">8</text>
              </g>
              <g ref={cueBall} transform={`translate(${START.x} ${START.y})`}>
                <circle r={BALL_R} fill="url(#cue-shade)" />
              </g>
            </svg>
            <figcaption className="mt-4 flex justify-between font-mono text-[12.5px] uppercase tracking-[0.24em] text-ink/50">
              <span>Perspective · Precision · Strategy</span>
              <span>Think ahead</span>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}
