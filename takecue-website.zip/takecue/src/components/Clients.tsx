import { useRef } from 'react';
import { CLIENTS, CLIENTS_INTRO } from '../content';
import { useReveal } from '../lib/useReveal';

export function Clients({ reduced }: { reduced: boolean }) {
  const root = useRef<HTMLElement>(null);
  useReveal(root, reduced);
  return (
    <section id="clients" ref={root} className="relative bg-ink" aria-labelledby="clients-title">
      <div className="hero-pad-x mx-auto max-w-[1440px] py-24 md:py-36">
        <div className="grid gap-8 md:grid-cols-12">
          <div className="md:col-span-7">
            <p className="kicker" data-reveal>
              <span className="text-paper/40">05</span> — {CLIENTS_INTRO.kicker}
            </p>
            <h2
              id="clients-title"
              data-reveal
              className="mt-4 text-[clamp(2.4rem,5vw,5.2rem)] font-semibold leading-[0.92] tracking-[-0.023em]"
            >
              Different Stages.
              <br />
              <span className="text-paper/45">One Ambition: Growth.</span>
            </h2>
          </div>
          <p data-reveal className="self-end text-[17.5px] leading-[1.65] text-paper/80 sm:text-[19px] md:col-span-4 md:col-start-9">
            {CLIENTS_INTRO.lead}
          </p>
        </div>

        {/* The table: four segments, framed like a playing surface with pockets */}
        <div data-reveal className="relative mt-16 md:mt-24">
          <ul className="grid overflow-hidden rounded-[28px] border border-white/10 sm:grid-cols-2">
            {CLIENTS.map((c, i) => (
              <li
                key={c.title}
                className="group relative border-white/10 p-7 transition-colors duration-500 hover:bg-felt sm:p-10 md:p-12 [&:nth-child(n+2)]:border-t sm:[&:nth-child(2)]:border-l sm:[&:nth-child(2)]:border-t-0 sm:[&:nth-child(4)]:border-l"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[13px] tracking-[0.22em] text-paper/45 group-hover:text-paper/80">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  {/* stage marker: the journey from first ball to the eight */}
                  <span className="flex items-center gap-1.5" aria-hidden="true">
                    {[0, 1, 2, 3].map((k) => (
                      <span
                        key={k}
                        className={`h-2 w-2 rounded-full border transition-colors duration-500 ${
                          k <= i ? 'border-paper bg-paper' : 'border-white/25'
                        }`}
                      />
                    ))}
                  </span>
                </div>
                <h3 className="mt-14 text-[clamp(1.5rem,2.3vw,2.2rem)] font-semibold leading-[1.05] tracking-[-0.013em] md:mt-24">
                  {c.title}
                </h3>
                <p className="mt-4 max-w-[30rem] text-[17px] leading-[1.6] text-paper/80 group-hover:text-paper/85 sm:text-[18px]">
                  {c.body}
                </p>
              </li>
            ))}
          </ul>
          {/* pockets */}
          {['-left-2 -top-2', '-right-2 -top-2', '-left-2 -bottom-2', '-right-2 -bottom-2'].map((pos) => (
            <span key={pos} aria-hidden="true" className={`absolute ${pos} h-5 w-5 rounded-full border border-white/15 bg-ink`} />
          ))}
        </div>
      </div>
    </section>
  );
}
