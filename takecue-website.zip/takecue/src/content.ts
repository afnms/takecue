// Approved TAKE CUE website copy. Keep wording faithful to the brand document.

export const CONTACT = {
  whatsapp: {
    label: 'WhatsApp',
    display: '+966 53 285 8565',
    local: '0532858565',
    href: 'https://wa.me/966532858565',
  },
  email: {
    label: 'Email',
    display: 'lets@takecue.net',
    href: 'mailto:lets@takecue.net',
  },
  instagram: {
    label: 'Instagram',
    display: '@take.cue',
    href: 'https://www.instagram.com/take.cue/',
  },
} as const;

export const NAV = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'services', label: 'Services' },
  { id: 'framework', label: '8D Framework' },
  { id: 'contact', label: 'Contact' },
] as const;

export const HERO = {
  titleA: 'TAKE THE CUE.',
  titleB: 'FROM BUILDING TO BEYOND.',
  statement: 'Strategic direction. Meaningful growth. Lasting impact.',
  lead: 'We turn business potential into purposeful progress.',
  category: 'Business Development Consultancy',
  ctaPrimary: 'Explore Our Approach',
  ctaSecondary: "Let's Talk Business",
};

export const ABOUT = {
  kicker: 'Who We Are',
  title: 'Beyond Ideas. Into Business.',
  paragraphs: [
    'TAKE CUE is a business development consultancy helping businesses and entrepreneurs navigate their next stage of growth.',
    'We bring together strategic thinking, market understanding, and practical execution to help businesses define their direction, strengthen their market position, and unlock new opportunities.',
    'From early-stage development to business expansion, we work alongside our clients to turn potential into progress.',
  ],
  closing: "We don't just identify what comes next. We help make it happen.",
};

export const SERVICES_INTRO = {
  kicker: 'What We Do',
  title: 'We Move Businesses Forward.',
  lead: 'We provide integrated business development solutions designed to address the challenges businesses face at different stages of their journey.',
};

export type Service = {
  n: string;
  title: string;
  tagline: string;
  body: string[];
  items: string[];
};

export const SERVICES: Service[] = [
  {
    n: '01',
    title: 'Business Consulting & Strategy',
    tagline: 'Clarity Before Action.',
    body: [
      'We help businesses understand where they stand, identify where they can go, and define the strategic direction to get there.',
    ],
    items: [
      'Business Analysis & Assessment',
      'Strategic Planning',
      'Business Model Development',
      'Market Research & Feasibility Studies',
      'Growth & Expansion Strategies',
      'Business Performance & KPI Development',
    ],
  },
  {
    n: '02',
    title: 'Brand Positioning & Management',
    tagline: 'Define Your Position. Own Your Presence.',
    body: [
      "A strong brand is more than how it looks. It's how it is positioned, perceived, and experienced in the market.",
      'We help businesses establish a distinctive market position and manage a consistent, meaningful presence that strengthens their competitive standing.',
    ],
    items: [
      'Brand Positioning Strategy',
      'Market & Competitive Positioning',
      'Brand Strategy & Direction',
      'Brand Messaging & Communication',
      'Market Presence Management',
      'Brand Reputation & Perception',
    ],
  },
  {
    n: '03',
    title: 'Marketing & Growth',
    tagline: 'Turn Visibility Into Opportunity.',
    body: [
      'We develop marketing strategies that connect brands with the right audiences, communicate their value, and create opportunities for sustainable growth.',
    ],
    items: [
      'Marketing Strategy & Planning',
      'Digital Marketing',
      'Content Strategy & Development',
      'Social Media Management',
      'Campaign Planning & Management',
      'Marketing Performance & Analytics',
    ],
  },
  {
    n: '04',
    title: 'Sales Development',
    tagline: 'From Interest to Revenue.',
    body: [
      'We help businesses build stronger sales strategies, identify commercial opportunities, and improve the processes that turn prospects into customers.',
    ],
    items: [
      'Sales Strategy Development',
      'Sales Channel Development',
      'Lead Generation Strategy',
      'Customer Acquisition',
      'Sales Funnel Optimization',
      'Strategic Partnerships & Business Opportunities',
    ],
  },
  {
    n: '05',
    title: 'Customer Experience & Retention',
    tagline: 'Growth Beyond Acquisition.',
    body: [
      "Sustainable growth is not only about gaining customers. It's about creating meaningful experiences that keep them coming back.",
      'We help businesses strengthen customer relationships, improve engagement, and build long-term customer value.',
    ],
    items: [
      'Customer Journey Mapping',
      'Customer Experience Strategy',
      'Customer Retention Strategies',
      'Loyalty Programs',
      'Customer Engagement',
      'Customer Satisfaction & Performance Measurement',
    ],
  },
  {
    n: '06',
    title: 'Business & Project Development',
    tagline: 'From Concept to Market.',
    body: [
      'We support businesses in transforming ideas and opportunities into structured initiatives, market-ready products, and executable projects.',
    ],
    items: [
      'Business Development',
      'Product & Service Development',
      'Project Planning & Management',
      'Go-to-Market Strategy',
      'Business Launch & Market Entry',
      'Partnership Development',
    ],
  },
];

export const FRAMEWORK_INTRO = {
  kicker: 'Our Methodology',
  title: 'THE 8D FRAMEWORK.',
  subtitle: 'Eight Dimensions. One Direction: Beyond.',
  lead: 'Every business has a different starting point, challenge, and ambition. Our 8D Framework provides a structured approach to understanding, directing, developing, and advancing businesses.',
  closing: 'Eight deliberate dimensions. One strategic direction.',
};

export type Stage = { n: string; name: string; verb: string; body: string };

export const STAGES: Stage[] = [
  { n: '01', name: 'DECODE', verb: 'Understand', body: 'We analyze the business, uncover challenges, and understand its current position.' },
  { n: '02', name: 'DEFINE', verb: 'Establish', body: 'We define objectives, priorities, and the direction that aligns with the business vision.' },
  { n: '03', name: 'DISCOVER', verb: 'Explore', body: 'We identify market opportunities, understand audiences, and uncover potential for growth.' },
  { n: '04', name: 'DIRECT', verb: 'Strategize', body: 'We translate insights into a clear strategic roadmap and actionable decisions.' },
  { n: '05', name: 'DESIGN', verb: 'Develop', body: 'We develop tailored solutions, strategies, and business initiatives that move the vision forward.' },
  { n: '06', name: 'DELIVER', verb: 'Execute', body: 'We turn strategies into action through structured implementation and execution.' },
  { n: '07', name: 'DEEPEN', verb: 'Strengthen', body: 'We strengthen customer relationships, market presence, and business capabilities to support lasting growth.' },
  { n: '08', name: 'DETERMINE', verb: 'Measure & Advance', body: 'We evaluate outcomes, measure impact, and determine the next opportunities for progress.' },
];

export const CLIENTS_INTRO = {
  kicker: 'Who We Work With',
  title: 'Different Stages. One Ambition: Growth.',
  lead: 'We partner with businesses at different stages of development, helping them navigate challenges and move towards their next opportunity.',
};

export const CLIENTS = [
  { title: 'Startups & Entrepreneurs', body: 'For founders turning ideas into viable businesses, entering the market, and building a foundation for growth.' },
  { title: 'Small & Medium Enterprises', body: 'For businesses looking to strengthen their operations, improve performance, and unlock new growth opportunities.' },
  { title: 'Established Businesses', body: 'For organizations seeking strategic development, market expansion, stronger positioning, and new business opportunities.' },
  { title: 'Organizations & Ecosystem Partners', body: 'For institutions, incubators, accelerators, and entities working to develop businesses and entrepreneurial ecosystems.' },
];

export const WHY_INTRO = {
  kicker: 'Why Take Cue?',
  title: 'The Right Perspective. The Right Direction. The Right Move.',
};

export const WHY = [
  { title: 'Strategic Perspective', body: 'We look beyond immediate challenges to understand the bigger picture and identify meaningful opportunities.' },
  { title: 'Integrated Thinking', body: 'We connect strategy, brand positioning, marketing, sales, and customer experience to create a unified business direction.' },
  { title: 'Action-Oriented Approach', body: 'We bridge the gap between planning and execution, turning strategic recommendations into practical initiatives.' },
  { title: 'Growth with Purpose', body: 'We focus on measurable progress, stronger market positions, and sustainable business development.' },
];

export const PHILOSOPHY = {
  kicker: 'Our Philosophy',
  title: 'EVERY MOVE MATTERS.',
  lead: 'In business, as in billiards, success is rarely a matter of chance.',
  body: [
    'It takes perspective to see the table, precision to choose the right angle, and strategy to anticipate what comes next.',
    'At TAKE CUE, we believe every decision should have a purpose, every action should create value, and every move should bring your business closer to its next milestone.',
  ],
  closing: 'Think Ahead. Take the Cue.',
};

export const CONNECT = {
  kicker: "Let's Connect",
  titleA: 'YOUR NEXT MOVE STARTS HERE.',
  titleB: "LET'S TAKE YOUR BUSINESS BEYOND.",
  talk: "Let's talk business.",
  lead: "Whether you're building, growing, or expanding, we're ready to help you find the right direction.",
};

export const FOOTER = {
  name: 'TAKE CUE',
  arabic: 'كيو الاستشارية لتطوير الأعمال',
  category: 'Business Development Consultancy',
  slogan: 'Take the Cue. From Building to Beyond.',
  links: [
    { id: 'about', label: 'About Us' },
    { id: 'services', label: 'Our Services' },
    { id: 'framework', label: 'The 8D Framework' },
    { id: 'contact', label: 'Contact' },
  ],
  copyright: '© 2026 TAKE CUE. All Rights Reserved.',
};
