import { CanvasTexture, RepeatWrapping, SRGBColorSpace, Vector3 } from 'three';

type RGB = [number, number, number];

export type Decal = {
  dir: Vector3; // centre of the decal on the unit sphere (local space)
  angle: number; // angular radius (rad)
  color: RGB;
  glyph?: { text: string; color: RGB; scale: number; weight?: number };
};

const hex = (h: string): RGB => {
  const n = parseInt(h.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

function glyphMask(text: string, weight = 700, size = 512) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  g.fillStyle = '#fff';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.font = `${weight} ${Math.round(size * 0.86)}px "Cormorant Garamond", Georgia, serif`;
  const m = g.measureText(text);
  const asc = m.actualBoundingBoxAscent;
  const desc = m.actualBoundingBoxDescent;
  g.fillText(text, size / 2, size / 2 + (asc - desc) / 2);
  return { data: g.getImageData(0, 0, size, size).data, size };
}

function sampleMask(mask: { data: Uint8ClampedArray; size: number }, u: number, v: number) {
  const s = mask.size;
  const x = u * s - 0.5;
  const y = v * s - 0.5;
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const at = (xx: number, yy: number) =>
    xx < 0 || yy < 0 || xx >= s || yy >= s ? 0 : mask.data[(yy * s + xx) * 4 + 3] / 255;
  const a = at(x0, y0) * (1 - fx) + at(x0 + 1, y0) * fx;
  const b = at(x0, y0 + 1) * (1 - fx) + at(x0 + 1, y0 + 1) * fx;
  return a * (1 - fy) + b * fy;
}

/**
 * Paints an equirectangular ball texture where every decal is projected
 * onto the sphere (so circles stay circles and the "8" is undistorted).
 */
export function ballTexture(base: string, decals: Decal[], width = 1024) {
  const W = width;
  const H = width / 2;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const g = c.getContext('2d')!;
  const img = g.createImageData(W, H);
  const baseRGB = hex(base);
  const prepared = decals.map((d) => {
    const dir = d.dir.clone().normalize();
    const worldUp = Math.abs(dir.y) > 0.95 ? new Vector3(0, 0, 1) : new Vector3(0, 1, 0);
    const right = new Vector3().crossVectors(worldUp, dir).normalize();
    const up = new Vector3().crossVectors(dir, right).normalize();
    return {
      ...d,
      dir,
      right,
      up,
      cos: Math.cos(d.angle),
      sin: Math.sin(d.angle),
      mask: d.glyph ? glyphMask(d.glyph.text, d.glyph.weight) : null,
    };
  });
  const edge = (Math.PI / H) * 1.4;
  const p = new Vector3();
  for (let py = 0; py < H; py++) {
    const theta = ((py + 0.5) / H) * Math.PI;
    const st = Math.sin(theta);
    const ct = Math.cos(theta);
    for (let px = 0; px < W; px++) {
      const phi = ((px + 0.5) / W) * Math.PI * 2;
      p.set(-Math.cos(phi) * st, ct, Math.sin(phi) * st);
      let r = baseRGB[0];
      let gg = baseRGB[1];
      let b = baseRGB[2];
      for (const d of prepared) {
        const dot = p.dot(d.dir);
        if (dot < d.cos - 0.05) continue;
        const ang = Math.acos(Math.min(1, dot));
        const cover = Math.min(1, Math.max(0, (d.angle - ang) / edge + 0.5));
        if (cover <= 0) continue;
        let cr = d.color[0];
        let cg = d.color[1];
        let cb = d.color[2];
        if (d.mask && d.glyph) {
          const a = p.dot(d.right) / d.sin;
          const bb = p.dot(d.up) / d.sin;
          const s = d.glyph.scale;
          const m = sampleMask(d.mask, a / (2 * s) + 0.5, 0.5 - bb / (2 * s));
          cr += (d.glyph.color[0] - cr) * m;
          cg += (d.glyph.color[1] - cg) * m;
          cb += (d.glyph.color[2] - cb) * m;
        }
        r += (cr - r) * cover;
        gg += (cg - gg) * cover;
        b += (cb - b) * cover;
      }
      const i = (py * W + px) * 4;
      img.data[i] = r;
      img.data[i + 1] = gg;
      img.data[i + 2] = b;
      img.data[i + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

export function eightBallTexture(width = 2048) {
  return ballTexture(
    '#0b0b0b',
    [
      {
        dir: new Vector3(0, 0, 1),
        angle: 0.5,
        color: hex('#f6f5f1'),
        glyph: { text: '8', color: hex('#0b0b0b'), scale: 0.86, weight: 700 },
      },
    ],
    width,
  );
}

export function cueBallTexture(width = 512) {
  // Tetrahedral spot pattern in brand green — makes the roll readable.
  const g = hex('#1E402B');
  const dirs = [
    new Vector3(1, 1, 1),
    new Vector3(1, -1, -1),
    new Vector3(-1, 1, -1),
    new Vector3(-1, -1, 1),
  ];
  return ballTexture('#f4f3ef', dirs.map((dir) => ({ dir, angle: 0.085, color: g })), width);
}

export function feltTexture(size = 512) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const img = g.createImageData(size, size);
  const [r, gg, b] = hex('#1E402B');
  for (let i = 0; i < size * size; i++) {
    const n = (Math.random() - 0.5) * 14 + (Math.random() < 0.02 ? 8 : 0);
    img.data[i * 4] = Math.max(0, r * 0.72 + n * 0.6);
    img.data[i * 4 + 1] = Math.max(0, gg * 0.72 + n);
    img.data[i * 4 + 2] = Math.max(0, b * 0.72 + n * 0.7);
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  tex.wrapS = tex.wrapT = RepeatWrapping;
  tex.repeat.set(14, 8);
  tex.anisotropy = 8;
  return tex;
}

export function radialTexture(inner = 'rgba(0,0,0,0.85)', size = 256) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, inner);
  grd.addColorStop(0.35, inner.replace(/[\d.]+\)$/, '0.55)'));
  grd.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  const tex = new CanvasTexture(c);
  return tex;
}

export function labelTexture(text: string) {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 128;
  const g = c.getContext('2d')!;
  g.fillStyle = '#fff';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.font = '600 72px "Cormorant Garamond", Georgia, serif';
  g.fillText(text, 128, 68);
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  return tex;
}

/** Tangent-space normal map of felt nap: fine fibres plus a slow cloth undulation. */
export function feltNormalTexture(size = 512) {
  const h = new Float32Array(size * size);
  for (let i = 0; i < h.length; i++) h[i] = Math.random();
  // directional fibres: short blur along x
  const f = new Float32Array(size * size);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      let s = 0;
      for (let k = -2; k <= 2; k++) s += h[y * size + ((x + k + size) % size)];
      f[y * size + x] = s / 5 + 0.08 * Math.sin((x / size) * Math.PI * 6) * Math.sin((y / size) * Math.PI * 4);
    }
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const img = g.createImageData(size, size);
  const at = (x: number, y: number) => f[((y + size) % size) * size + ((x + size) % size)];
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const dx = (at(x + 1, y) - at(x - 1, y)) * 1.6;
      const dy = (at(x, y + 1) - at(x, y - 1)) * 1.6;
      const len = Math.hypot(dx, dy, 1);
      const i = (y * size + x) * 4;
      img.data[i] = ((-dx / len) * 0.5 + 0.5) * 255;
      img.data[i + 1] = ((-dy / len) * 0.5 + 0.5) * 255;
      img.data[i + 2] = (1 / len) * 255;
      img.data[i + 3] = 255;
    }
  g.putImageData(img, 0, 0);
  const tex = new CanvasTexture(c);
  tex.wrapS = tex.wrapT = RepeatWrapping;
  tex.repeat.set(14, 8);
  tex.anisotropy = 8;
  return tex;
}

/** Roughness map for phenolic balls: polished, with faint smudges and micro-wear. */
export function ballRoughnessTexture(size = 512) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size / 2;
  const g = c.getContext('2d')!;
  g.fillStyle = 'rgb(28,28,28)'; // ≈ 0.11 roughness
  g.fillRect(0, 0, c.width, c.height);
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * c.width;
    const y = c.height * (0.2 + Math.random() * 0.6);
    const r = 6 + Math.random() * 26;
    const grd = g.createRadialGradient(x, y, 0, x, y, r);
    const v = 50 + Math.random() * 40;
    grd.addColorStop(0, `rgba(${v},${v},${v},0.55)`);
    grd.addColorStop(1, 'rgba(28,28,28,0)');
    g.fillStyle = grd;
    g.beginPath();
    g.ellipse(x, y, r * 1.6, r, Math.random() * Math.PI, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 0.18;
  g.strokeStyle = 'rgb(70,70,70)';
  for (let i = 0; i < 140; i++) {
    g.lineWidth = Math.random() * 0.8;
    g.beginPath();
    const x = Math.random() * c.width;
    const y = Math.random() * c.height;
    g.moveTo(x, y);
    g.lineTo(x + (Math.random() - 0.5) * 30, y + (Math.random() - 0.5) * 8);
    g.stroke();
  }
  const tex = new CanvasTexture(c);
  tex.anisotropy = 4;
  return tex;
}
