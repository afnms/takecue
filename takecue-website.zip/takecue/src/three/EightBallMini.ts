import {
  ACESFilmicToneMapping,
  DirectionalLight,
  HemisphereLight,
  Mesh,
  PerspectiveCamera,
  Quaternion,
  Scene,
  SRGBColorSpace,
  Vector3,
  WebGLRenderer,
} from 'three';
import { ballGeometry, ballMaterial, studioEnvironment } from './assets';
import { eightBallTexture } from './textures';

/** The closing eight ball: slow, weighty idle spin that leans toward the pointer. */
export class EightBallMini {
  private renderer: WebGLRenderer;
  private scene = new Scene();
  private camera = new PerspectiveCamera(26, 1, 0.1, 50);
  private ball: Mesh;
  private raf = 0;
  private running = false;
  private last = 0;
  private t = 0;
  private pointer = { x: 0, y: 0 };
  private tilt = { x: 0, y: 0 };
  private q = new Quaternion();
  private base = new Quaternion();

  constructor(private canvas: HTMLCanvasElement, private reduced: boolean) {
    this.renderer = new WebGLRenderer({ canvas, alpha: true, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = SRGBColorSpace;
    this.renderer.toneMapping = ACESFilmicToneMapping;
    this.renderer.setClearColor(0x000000, 0);
    this.scene.environment = studioEnvironment(this.renderer);
    this.scene.add(new HemisphereLight('#ffffff', '#1E402B', 0.7));
    const key = new DirectionalLight('#ffffff', 1.4);
    key.position.set(-3, 5, 4);
    this.scene.add(key);
    this.ball = new Mesh(ballGeometry(72), ballMaterial(eightBallTexture(1024)));
    this.scene.add(this.ball);
    this.camera.position.set(0, 0.35, 6.4);
    this.camera.lookAt(0, 0, 0);
    // Rest pose: the "8" toward the viewer, a touch of tilt.
    this.base.setFromAxisAngle(new Vector3(0, 1, 0), -0.35).multiply(new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), 0.12));
    this.ball.quaternion.copy(this.base);
    this.resize();
    window.addEventListener('pointermove', this.onPointer, { passive: true });
    this.render(0);
  }

  private onPointer = (e: PointerEvent) => {
    this.pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
    this.pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
  };

  resize() {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (!this.running) this.render(0);
  }

  setRunning(on: boolean) {
    if (this.reduced || on === this.running) return;
    this.running = on;
    if (on) {
      this.last = performance.now();
      this.raf = requestAnimationFrame(this.loop);
    } else cancelAnimationFrame(this.raf);
  }

  private loop = (now: number) => {
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.render(dt);
    if (this.running) this.raf = requestAnimationFrame(this.loop);
  };

  private render(dt: number) {
    this.t += dt;
    const k = 1 - Math.exp(-dt * 3);
    this.tilt.x += (this.pointer.y * 0.35 - this.tilt.x) * k;
    this.tilt.y += (this.pointer.x * 0.55 - this.tilt.y) * k;
    const sway = Math.sin(this.t * 0.6) * 0.18;
    this.q.setFromAxisAngle(new Vector3(0, 1, 0), this.tilt.y + sway);
    this.q.multiply(new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), this.tilt.x));
    this.ball.quaternion.copy(this.q).multiply(this.base);
    this.ball.position.y = Math.sin(this.t * 0.9) * 0.04;
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.setRunning(false);
    window.removeEventListener('pointermove', this.onPointer);
    this.renderer.dispose();
  }
}
