import {
  BackSide,
  Color,
  Group,
  LatheGeometry,
  Mesh,
  MeshBasicMaterial,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  PlaneGeometry,
  PMREMGenerator,
  Scene,
  SphereGeometry,
  Texture,
  Vector2,
  WebGLRenderer,
} from 'three';
import { R } from './physics';

/** A dark studio with a single rectangular pool-lamp softbox, for reflections. */
export function studioEnvironment(renderer: WebGLRenderer): Texture {
  const env = new Scene();
  const room = new Mesh(
    new SphereGeometry(40, 32, 16),
    new MeshBasicMaterial({ color: new Color('#050505'), side: BackSide }),
  );
  env.add(room);
  const lamp = (w: number, h: number, x: number, y: number, z: number, k: number, rx = Math.PI / 2) => {
    const m = new Mesh(
      new PlaneGeometry(w, h),
      new MeshBasicMaterial({ color: new Color(1, 1, 1).multiplyScalar(k), side: 2 }),
    );
    m.position.set(x, y, z);
    m.rotation.x = rx;
    env.add(m);
  };
  lamp(16, 4.5, 0, 14, 0, 7); // overhead table lamp
  lamp(30, 2, 0, 4, -22, 0.9, 0); // faint back strip → rim reflection
  lamp(8, 2, -20, 6, 10, 0.5, 0); // faint key fill
  const pmrem = new PMREMGenerator(renderer);
  const tex = pmrem.fromScene(env, 0.02).texture;
  pmrem.dispose();
  env.traverse((o) => {
    if (o instanceof Mesh) {
      o.geometry.dispose();
      (o.material as MeshBasicMaterial).dispose();
    }
  });
  return tex;
}

export function ballMaterial(map: Texture) {
  return new MeshPhysicalMaterial({
    map,
    roughness: 0.16,
    metalness: 0,
    clearcoat: 1,
    clearcoatRoughness: 0.035,
    envMapIntensity: 1.15,
  });
}

export function ballGeometry(detail = 64) {
  return new SphereGeometry(R, detail, Math.round(detail * 0.75));
}

/**
 * A two-piece cue built from lathe profiles, laid along +Y with the tip at
 * the origin. Proportions follow a real cue relative to a 57 mm ball.
 */
export function buildCue(): Group {
  const group = new Group();
  const L = 36;
  const seg = (pts: [number, number][], mat: MeshStandardMaterial | MeshPhysicalMaterial, radial = 40) => {
    const geo = new LatheGeometry(
      pts.map(([r, y]) => new Vector2(r, y)),
      radial,
    );
    const m = new Mesh(geo, mat);
    m.castShadow = true;
    group.add(m);
    return m;
  };
  const tip = new MeshStandardMaterial({ color: '#1E402B', roughness: 0.95 });
  const ferrule = new MeshPhysicalMaterial({ color: '#f4f3ef', roughness: 0.25, clearcoat: 0.6 });
  const shaft = new MeshPhysicalMaterial({ color: '#dcd6c9', roughness: 0.38, clearcoat: 0.4, clearcoatRoughness: 0.3 });
  const green = new MeshPhysicalMaterial({ color: '#1E402B', roughness: 0.25, metalness: 0.4, clearcoat: 1 });
  const lacquer = new MeshPhysicalMaterial({ color: '#0c0c0c', roughness: 0.22, clearcoat: 1, clearcoatRoughness: 0.06 });
  const wrap = new MeshStandardMaterial({ color: '#1a1a1a', roughness: 0.9 });
  const white = new MeshPhysicalMaterial({ color: '#f4f3ef', roughness: 0.2, clearcoat: 1 });

  seg([[0, 0], [0.1, 0.008], [0.17, 0.035], [0.215, 0.08], [0.225, 0.16]], tip);
  seg([[0.225, 0.16], [0.232, 0.95]], ferrule);
  seg([[0.232, 0.95], [0.25, 4], [0.3, 11], [0.355, 17]], shaft);
  seg([[0.355, 17], [0.372, 17.05], [0.372, 17.5]], green);
  seg([[0.372, 17.5], [0.374, 17.6]], white);
  seg([[0.374, 17.6], [0.41, 23], [0.425, 24.8]], lacquer);
  seg([[0.425, 24.8], [0.43, 24.9]], green);
  seg([[0.43, 24.9], [0.445, 31.6]], wrap);
  seg([[0.445, 31.6], [0.46, 32.8]], lacquer);
  seg([[0.46, 32.8], [0.462, 33.05]], green);
  seg([[0.462, 33.05], [0.478, L - 0.25]], lacquer);
  seg([[0.478, L - 0.25], [0.46, L - 0.05], [0.3, L], [0, L]], wrap);
  return group;
}
