import { Quaternion, Vector3 } from 'three';
import { STORY } from '../lib/timeline';

/**
 * Deterministic, scroll-reversible billiards shot.
 * Everything is a closed-form function of simulation time τ so that
 * scrubbing the page forwards or backwards always yields the same frame.
 */

export const R = 1; // ball radius (world units)
export const CUE_START = new Vector3(-10, R, 0);
export const EIGHT_START = new Vector3(6, R, 0.62);

const V0 = 6.2; // cue ball speed off the tip (u/s)
const DECEL_IN = 0.5; // rolling resistance before contact
const DECEL_OUT = 1.7; // after contact (both balls)

const UP = new Vector3(0, 1, 0);
const X = new Vector3(1, 0, 0);

// ---- Contact geometry (cut shot: cue ball travels on +x, object ball offset on z) ----
const dz = EIGHT_START.z - CUE_START.z;
const dxAtContact = Math.sqrt(4 * R * R - dz * dz);
export const CONTACT_POINT_CUE = new Vector3(EIGHT_START.x - dxAtContact, R, CUE_START.z);
const D1 = CONTACT_POINT_CUE.x - CUE_START.x;
export const T_CONTACT = (V0 - Math.sqrt(V0 * V0 - 2 * DECEL_IN * D1)) / DECEL_IN;
const V_AT_CONTACT = V0 - DECEL_IN * T_CONTACT;

// Line of centres at impact.
export const N = new Vector3().subVectors(EIGHT_START, CONTACT_POINT_CUE).normalize();
// Equal-mass elastic collision: object ball takes the normal component,
// cue ball keeps the tangential component (they part at ~90°).
const vIn = X.clone().multiplyScalar(V_AT_CONTACT);
const V8 = N.clone().multiplyScalar(vIn.dot(N));
const VQ = vIn.clone().sub(V8);
const S8 = V8.length();
const SQ = VQ.length();
const DIR8 = V8.clone().normalize();
const DIRQ = VQ.clone().normalize();
const T8_STOP = S8 / DECEL_OUT;
const TQ_STOP = SQ / DECEL_OUT;
export const T_END = T_CONTACT + Math.max(T8_STOP, TQ_STOP);

const D8_TOTAL = (S8 * S8) / (2 * DECEL_OUT);
export const EIGHT_FINAL = EIGHT_START.clone().addScaledVector(DIR8, D8_TOTAL);
export const IMPACT_POINT = CONTACT_POINT_CUE.clone().addScaledVector(N, R).setY(0.01);

function travelled(t: number, speed: number, decel: number) {
  const tc = Math.min(Math.max(t, 0), speed / decel);
  return speed * tc - 0.5 * decel * tc * tc;
}
function speedAt(t: number, speed: number, decel: number) {
  if (t < 0) return 0;
  return Math.max(0, speed - decel * t);
}

const rollAxis = (dir: Vector3) => new Vector3().crossVectors(UP, dir).normalize();
const AXIS_IN = rollAxis(X);
const AXIS_Q = rollAxis(DIRQ);
const AXIS_8 = rollAxis(DIR8);
const qa = new Quaternion();
const qb = new Quaternion();

export type ShotState = {
  cue: Vector3;
  eight: Vector3;
  cueQ: Quaternion;
  eightQ: Quaternion;
  cueSpeed: number;
  eightSpeed: number;
};

/** Orientation the eight ball should have once it stops, so the "8" faces the final camera. */
let EIGHT_Q0 = new Quaternion();
export function setEightTargetOrientation(target: Quaternion) {
  qa.setFromAxisAngle(AXIS_8, D8_TOTAL / R);
  EIGHT_Q0 = qa.clone().invert().multiply(target);
}

export function shotAt(t: number, out: ShotState): ShotState {
  // Cue ball
  const d1 = travelled(t, V0, DECEL_IN);
  if (t <= T_CONTACT) {
    out.cue.copy(CUE_START).addScaledVector(X, d1);
    out.cueQ.setFromAxisAngle(AXIS_IN, d1 / R);
    out.cueSpeed = speedAt(t, V0, DECEL_IN);
  } else {
    const d2 = travelled(t - T_CONTACT, SQ, DECEL_OUT);
    out.cue.copy(CONTACT_POINT_CUE).addScaledVector(DIRQ, d2);
    qa.setFromAxisAngle(AXIS_IN, D1 / R);
    qb.setFromAxisAngle(AXIS_Q, d2 / R);
    out.cueQ.copy(qb).multiply(qa);
    out.cueSpeed = speedAt(t - T_CONTACT, SQ, DECEL_OUT);
  }
  // Eight ball
  const d8 = t > T_CONTACT ? travelled(t - T_CONTACT, S8, DECEL_OUT) : 0;
  out.eight.copy(EIGHT_START).addScaledVector(DIR8, d8);
  qb.setFromAxisAngle(AXIS_8, d8 / R);
  out.eightQ.copy(qb).multiply(EIGHT_Q0);
  out.eightSpeed = t > T_CONTACT ? speedAt(t - T_CONTACT, S8, DECEL_OUT) : 0;
  return out;
}

export function newShotState(): ShotState {
  return {
    cue: new Vector3(),
    eight: new Vector3(),
    cueQ: new Quaternion(),
    eightQ: new Quaternion(),
    cueSpeed: 0,
    eightSpeed: 0,
  };
}

// ---- Scroll → simulation-time warp ----
// A playback-rate curve: quick launch off the cue, cinematic slow-motion
// through the impact, then natural roll-out. Integrated into a lookup table.
const RATE_KEYS: [number, number][] = [
  [0, 1.6],
  [0.2, 0.95],
  [0.42, 0.42],
  [0.56, 0.42],
  [0.74, 1.0],
  [1, 1.15],
];
function rate(u: number) {
  for (let i = 0; i < RATE_KEYS.length - 1; i++) {
    const [u0, r0] = RATE_KEYS[i];
    const [u1, r1] = RATE_KEYS[i + 1];
    if (u <= u1) {
      const k = (u - u0) / (u1 - u0);
      const s = k * k * (3 - 2 * k);
      return r0 + (r1 - r0) * s;
    }
  }
  return RATE_KEYS[RATE_KEYS.length - 1][1];
}
const LUT_N = 600;
const LUT = new Float32Array(LUT_N + 1);
(() => {
  let acc = 0;
  LUT[0] = 0;
  for (let i = 1; i <= LUT_N; i++) {
    const u = (i - 0.5) / LUT_N;
    acc += rate(u) / LUT_N;
    LUT[i] = acc;
  }
  for (let i = 0; i <= LUT_N; i++) LUT[i] = (LUT[i] / acc) * T_END;
})();

/** Story progress → simulation time (0 before the strike). */
export function simTime(p: number) {
  const [a, b] = [STORY.contactTip, STORY.rollEnd];
  if (p <= a) return 0;
  if (p >= b) return T_END;
  const f = ((p - a) / (b - a)) * LUT_N;
  const i = Math.floor(f);
  return LUT[i] + (LUT[i + 1] - LUT[i]) * (f - i);
}

/** Story progress at which the balls collide. */
export const P_COLLISION = (() => {
  const [a, b] = [STORY.contactTip, STORY.rollEnd];
  for (let i = 0; i < LUT_N; i++) {
    if (LUT[i + 1] >= T_CONTACT) {
      const k = (T_CONTACT - LUT[i]) / (LUT[i + 1] - LUT[i]);
      return a + ((i + k) / LUT_N) * (b - a);
    }
  }
  return (a + b) / 2;
})();
