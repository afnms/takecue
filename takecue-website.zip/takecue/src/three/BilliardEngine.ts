import {
  ACESFilmicToneMapping,
  HemisphereLight,
  AdditiveBlending,
  AmbientLight,
  BoxGeometry,
  CircleGeometry,
  Color,
  DirectionalLight,
  Fog,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  Object3D,
  Points,
  ShaderMaterial,
  PCFSoftShadowMap,
  PerspectiveCamera,
  PlaneGeometry,
  Quaternion,
  Raycaster,
    Scene,
  SphereGeometry,
  SpotLight,
  Sprite,
  SpriteMaterial,
  SRGBColorSpace,
  Texture,
  TorusGeometry,
  Vector2,
  Vector3,
  WebGLRenderer,
} from 'three';
import { STORY, clamp, easeInOut, easeOut, lerp, range, smooth } from '../lib/timeline';
import { ballGeometry, ballMaterial, buildCue, studioEnvironment } from './assets';
import {
  CUE_START,
  EIGHT_FINAL,
  IMPACT_POINT,
  P_COLLISION,
  R,
  newShotState,
  setEightTargetOrientation,
  shotAt,
  simTime,
} from './physics';
import { ballRoughnessTexture, cueBallTexture, eightBallTexture, feltNormalTexture, feltTexture, labelTexture, radialTexture } from './textures';
import { createCinematic, dustMotes, lightShaft, type Cinematic } from './cinematic';

export type Quality = 'high' | 'low';

export type EngineOptions = {
  quality: Quality;
  reduced: boolean;
  onStageSelect?: (index: number) => void;
};

type CamKey = {
  p: number;
  pos: Vector3;
  tgt: Vector3;
  fov: number;
  fx: number;
  fy: number;
  mfx?: number;
  mfy?: number;
  /** maximum dolly-out factor on narrow (portrait) screens */
  max: number;
  /** explicit portrait camera position (overrides dolly-out) */
  mpos?: Vector3;
};

const v = (x: number, y: number, z: number) => new Vector3(x, y, z);
const C = CUE_START;
const F = EIGHT_FINAL;
const FINAL_OFFSET = v(-2.3, 2.5, 11.4);
const PC = clamp(P_COLLISION, 0.57, 0.7);

const KEYS: CamKey[] = [
  { p: 0, pos: C.clone().add(v(0, 1.9, 11.4)), tgt: C.clone().add(v(0, 0.15, 0)), fov: 30, fx: 0.5, fy: 0.5, mfy: 0.47, max: 1.55 },
  { p: 0.07, pos: C.clone().add(v(-2.6, 2.6, 11)), tgt: C.clone(), fov: 30, fx: 0.5, fy: 0.52, mfy: 0.45, max: 1.7 },
  { p: 0.19, pos: v(-27, 11, 7), tgt: v(-3, 0, 0), fov: 36, fx: 0.34, fy: 0.52, mfx: 0.5, mfy: 0.3, max: 1.6 },
  { p: 0.38, pos: v(-25.4, 10.2, 6.6), tgt: v(-3, 0, 0), fov: 36, fx: 0.34, fy: 0.52, mfx: 0.5, mfy: 0.3, max: 1.6 },
  { p: 0.45, pos: v(-21.5, 8, 7.8), tgt: v(-2, 0.3, 0), fov: 34, fx: 0.45, fy: 0.53, mfx: 0.5, mfy: 0.4, max: 1.8 },
  { p: 0.53, pos: v(-4.5, 4.4, 12.5), tgt: v(1.2, 1, 0.3), fov: 30, fx: 0.5, fy: 0.55, mfy: 0.42, max: 2.3 },
  { p: PC, pos: v(IMPACT_POINT.x - 3.2, 2.7, 9.2), tgt: v(IMPACT_POINT.x + 0.4, 1, 0.5), fov: 30, fx: 0.5, fy: 0.55, mfy: 0.45, max: 2.5 },
  { p: 0.73, pos: v(IMPACT_POINT.x + 1.2, 4.0, 12.5), tgt: v(F.x - 2.6, 1, F.z * 0.7), fov: 30, fx: 0.45, fy: 0.55, mfx: 0.5, mfy: 0.4, max: 2.6 },
  { p: 0.95, pos: F.clone().add(FINAL_OFFSET), tgt: F.clone().add(v(0, 0.2, 0)), fov: 30, fx: 0.25, fy: 0.5, mfx: 0.5, mfy: 0.27, max: 2.2, mpos: F.clone().add(v(-3.2, 14.2, 15.6)) },
  { p: 1, pos: F.clone().add(FINAL_OFFSET), tgt: F.clone().add(v(0, 0.2, 0)), fov: 30, fx: 0.25, fy: 0.5, mfx: 0.5, mfy: 0.27, max: 2.2, mpos: F.clone().add(v(-3.2, 14.2, 15.6)) },
];

/** Non-uniform Catmull–Rom (Hermite) through keyed times. */
function hermite(keys: CamKey[], pts: Vector3[], p: number, out: Vector3) {
  const n = keys.length;
  if (p <= keys[0].p) return out.copy(pts[0]);
  if (p >= keys[n - 1].p) return out.copy(pts[n - 1]);
  let i = 0;
  while (i < n - 2 && p > keys[i + 1].p) i++;
  const t0 = keys[i].p;
  const t1 = keys[i + 1].p;
  const dt = t1 - t0;
  const u = (p - t0) / dt;
  const p0 = pts[i];
  const p1 = pts[i + 1];
  const tangent = (k: number) => {
    const a = pts[Math.max(0, k - 1)];
    const b = pts[Math.min(n - 1, k + 1)];
    const ta = keys[Math.max(0, k - 1)].p;
    const tb = keys[Math.min(n - 1, k + 1)].p;
    return new Vector3().subVectors(b, a).multiplyScalar(dt / Math.max(1e-4, tb - ta));
  };
  const m0 = tangent(i);
  const m1 = tangent(i + 1);
  const u2 = u * u;
  const u3 = u2 * u;
  const h00 = 2 * u3 - 3 * u2 + 1;
  const h10 = u3 - 2 * u2 + u;
  const h01 = -2 * u3 + 3 * u2;
  const h11 = u3 - u2;
  return out
    .copy(p0)
    .multiplyScalar(h00)
    .addScaledVector(m0, h10)
    .addScaledVector(p1, h01)
    .addScaledVector(m1, h11);
}

function scalarAt(keys: CamKey[], p: number, get: (k: CamKey) => number) {
  if (p <= keys[0].p) return get(keys[0]);
  for (let i = 0; i < keys.length - 1; i++) {
    if (p <= keys[i + 1].p) {
      const u = smooth((p - keys[i].p) / (keys[i + 1].p - keys[i].p));
      return lerp(get(keys[i]), get(keys[i + 1]), u);
    }
  }
  return get(keys[keys.length - 1]);
}

const STAGE_COUNT = 8;
const ORBIT_R = 1.85;
const LIGHT_GREEN = new Color('#3c7a55');

export class BilliardEngine {
  readonly renderer: WebGLRenderer;
  private scene = new Scene();
  private overlay = new Scene();
  readonly camera = new PerspectiveCamera(30, 1, 0.1, 200);
  private opts: EngineOptions;

  private cueBall: Mesh;
  private eightBall: Mesh;
  private cueBallShadow: Mesh;
  private eightBallShadow: Mesh;
  readonly cuePivot = new Group();
  private cueShadow: Mesh;
  private impactGlow: Sprite;
  private strikeGlow: Sprite;
  private heroSpot: SpotLight;
  private mainSpot: SpotLight;
  private focusSpot: SpotLight;
  private cine: Cinematic;
  private heroShaft: Mesh;
  private focusShaft: Mesh;
  private heroDust: Points;
  private focusDust: Points;
  private focusPoint = new Vector3();

  private orbit = new Group();
  private orbitInner = new Group();
  private orbitBase: Mesh;
  private orbitArc: Mesh;
  private orbitArcValue = -1;
  private markers: Mesh[] = [];
  private labels: Sprite[] = [];
  private activeHalo: Mesh;

  private shot = newShotState();
  private camPts: Vector3[] = [];
  private tgtPts: Vector3[] = [];
  private tmpPos = new Vector3();
  private tmpTgt = new Vector3();
  private tmpQ = new Quaternion();
  private yAxis = new Vector3(0, 1, 0);

  private storyTarget = 0;
  private story = 0;
  private fwTarget = 0;
  private fw = 0;
  private fwVisible = 0;
  private activeStage = 0;
  private width = 1;
  private height = 1;
  private portrait = false;
  private running = false;
  private raf = 0;
  private last = 0;
  private time = 0;
  private frameTimes: number[] = [];
  private pixelRatio = 1;
  private raycaster = new Raycaster();
  private pointer = new Vector2();
  private disposables: { dispose: () => void }[] = [];

  constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    this.opts = opts;
    const high = opts.quality === 'high';
    this.renderer = new WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, high ? 1.75 : 1.35);
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.outputColorSpace = SRGBColorSpace;
    this.renderer.toneMapping = ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = PCFSoftShadowMap;
    this.renderer.setClearColor('#111111');

    const scene = this.scene;
    scene.background = new Color('#111111');
    scene.fog = new Fog('#111111', 20, 64);
    const env = studioEnvironment(this.renderer);
    scene.environment = env;
    this.disposables.push(env);

    // ---------- Lights ----------
    scene.add(new AmbientLight('#ffffff', 0.03));
    // Felt bounce: lifts the underside of the balls with a whisper of green.
    scene.add(new HemisphereLight('#ffffff', '#2a5a3c', 0.55));
    const rim = new DirectionalLight('#ffffff', 0.55);
    rim.position.set(2, 7, -14);
    scene.add(rim);

    this.heroSpot = new SpotLight('#fffaf0', 0, 40, 0.24, 1, 0);
    this.heroSpot.position.copy(C).add(v(0.8, 14, 3));
    this.heroSpot.target.position.copy(C);
    scene.add(this.heroSpot, this.heroSpot.target);

    this.mainSpot = new SpotLight('#fffaf2', 0, 80, 0.72, 0.85, 0);
    this.mainSpot.position.set(1.5, 26, 3);
    this.mainSpot.target.position.set(1.5, 0, 1);
    this.mainSpot.castShadow = true;
    this.mainSpot.shadow.mapSize.set(high ? 2048 : 1024, high ? 2048 : 1024);
    this.mainSpot.shadow.camera.near = 12;
    this.mainSpot.shadow.camera.far = 40;
    this.mainSpot.shadow.bias = -0.0004;
    this.mainSpot.shadow.normalBias = 0.03;
    this.mainSpot.shadow.radius = 6;
    scene.add(this.mainSpot, this.mainSpot.target);

    this.focusSpot = new SpotLight('#ffffff', 0, 40, 0.2, 1, 0);
    this.focusSpot.position.copy(F).add(v(-1.2, 15, 4));
    this.focusSpot.target.position.copy(F);
    scene.add(this.focusSpot, this.focusSpot.target);

    // ---------- Table ----------
    this.buildTable(high);

    // ---------- Balls ----------
    const geo = ballGeometry(high ? 72 : 48);
    const cueTex = cueBallTexture(high ? 512 : 256);
    const eightTex = eightBallTexture(high ? 2048 : 1024);
    this.cueBall = new Mesh(geo, ballMaterial(cueTex));
    this.eightBall = new Mesh(geo, ballMaterial(eightTex));
    const roughTex = ballRoughnessTexture(high ? 1024 : 512);
    this.disposables.push(roughTex);
    for (const b of [this.cueBall, this.eightBall]) {
      const m = b.material as MeshPhysicalMaterial;
      m.roughness = 1;
      m.roughnessMap = roughTex;
    }
    this.cueBall.castShadow = this.eightBall.castShadow = true;
    scene.add(this.cueBall, this.eightBall);
    this.disposables.push(geo, cueTex, eightTex, this.cueBall.material as MeshPhysicalMaterial, this.eightBall.material as MeshPhysicalMaterial);

    const blobTex = radialTexture('rgba(0,0,0,0.9)');
    const blob = (s: number) => {
      const m = new Mesh(
        new PlaneGeometry(s, s),
        new MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, opacity: 0.9 }),
      );
      m.rotation.x = -Math.PI / 2;
      m.position.y = 0.012;
      scene.add(m);
      return m;
    };
    this.cueBallShadow = blob(2.7 * R);
    this.eightBallShadow = blob(2.7 * R);
    this.disposables.push(blobTex);

    // The eight ball must come to rest with its "8" facing the final camera.
    const dummy = new Object3D();
    dummy.position.copy(F);
    dummy.lookAt(F.clone().add(FINAL_OFFSET));
    setEightTargetOrientation(dummy.quaternion);

    // ---------- Cue ----------
    const cue = buildCue();
    this.cuePivot.add(cue);
    scene.add(this.cuePivot);
    this.cueShadow = new Mesh(
      new PlaneGeometry(1, 1),
      new MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, opacity: 0.35 }),
    );
    this.cueShadow.rotation.x = -Math.PI / 2;
    this.cueShadow.position.y = 0.011;
    scene.add(this.cueShadow);

    // ---------- Impact accents ----------
    const glowTex = radialTexture('rgba(255,255,255,1)');
    this.disposables.push(glowTex);
    const glow = () =>
      new Sprite(new SpriteMaterial({ map: glowTex, transparent: true, opacity: 0, blending: AdditiveBlending, depthWrite: false }));
    this.impactGlow = glow();
    this.impactGlow.position.copy(IMPACT_POINT).setY(R);
    this.strikeGlow = glow();
    this.strikeGlow.position.copy(C).add(v(-R * 0.95, 0.15, 0));
    scene.add(this.impactGlow, this.strikeGlow);

    // ---------- 8D orbit ----------
    this.orbitBase = new Mesh(
      new TorusGeometry(ORBIT_R, 0.006, 6, 160),
      new MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.22, depthWrite: false }),
    );
    this.orbitArc = new Mesh(
      new TorusGeometry(ORBIT_R, 0.016, 6, 8, 0.01),
      new MeshBasicMaterial({ color: LIGHT_GREEN, transparent: true, opacity: 1, depthWrite: false }),
    );
    this.orbitInner.add(this.orbitBase, this.orbitArc);
    const markerGeo = new SphereGeometry(1, 20, 14);
    for (let i = 0; i < STAGE_COUNT; i++) {
      const a = Math.PI / 2 - (i / STAGE_COUNT) * Math.PI * 2;
      const m = new Mesh(markerGeo, new MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.5 }));
      m.position.set(Math.cos(a) * ORBIT_R, Math.sin(a) * ORBIT_R, 0);
      m.scale.setScalar(0.055);
      m.userData.index = i;
      this.markers.push(m);
      this.orbitInner.add(m);
      const tex = labelTexture(String(i + 1).padStart(2, '0'));
      const s = new Sprite(new SpriteMaterial({ map: tex, transparent: true, opacity: 0.45, depthWrite: false }));
      s.position.set(Math.cos(a) * (ORBIT_R + 0.52), Math.sin(a) * (ORBIT_R + 0.52), 0);
      s.scale.set(0.56, 0.28, 1);
      this.labels.push(s);
      this.orbitInner.add(s);
      this.disposables.push(tex, s.material);
    }
    this.activeHalo = new Mesh(
      new TorusGeometry(0.17, 0.01, 6, 48),
      new MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.9, depthWrite: false }),
    );
    this.orbitInner.add(this.activeHalo);
    this.orbit.add(this.orbitInner);
    // The halo floats above the table: never clipped by felt or rails.
    this.orbit.traverse((o) => {
      const m = (o as Mesh).material as MeshBasicMaterial | undefined;
      if (m) m.depthTest = false;
      o.renderOrder = 10;
    });
    this.orbit.position.copy(F);
    this.orbit.visible = false;
    this.overlay.add(this.orbit);
    this.disposables.push(markerGeo);

    // ---------- Cinematic atmosphere ----------
    const shaftFrom = (spot: SpotLight, radius: number) => {
      const top = spot.position.clone();
      const dir = spot.target.position.clone().sub(top);
      const m = lightShaft(dir.length(), radius);
      m.position.copy(top);
      m.quaternion.setFromUnitVectors(new Vector3(0, -1, 0), dir.normalize());
      scene.add(m);
      return m;
    };
    this.heroShaft = shaftFrom(this.heroSpot, 3.2);
    this.focusShaft = shaftFrom(this.focusSpot, 3.0);
    this.heroDust = dustMotes(high ? 260 : 120, C, 3.2, 9);
    this.focusDust = dustMotes(high ? 200 : 90, F, 3.0, 8);
    scene.add(this.heroDust, this.focusDust);
    this.cine = createCinematic(this.renderer, scene, this.camera, high, this.overlay);

    this.resize();
    if (opts.onStageSelect) {
      window.addEventListener('pointerdown', this.onPointerDown);
      window.addEventListener('pointermove', this.onPointerMove, { passive: true });
    }
    if (opts.reduced) {
      // A single, carefully composed poster frame: cue aimed, eight ball waiting.
      this.story = this.storyTarget = 0.3;
      this.renderFrame(0);
    }
  }

  // ---------------------------------------------------------------- Table
  private buildTable(high: boolean) {
    const TX = 1.5;
    const TZ = 1;
    const HW = 23;
    const HD = 13;
    const feltTex = feltTexture(high ? 512 : 256);
    const feltNormal = feltNormalTexture(high ? 512 : 256);
    this.disposables.push(feltNormal);
    const felt = new MeshStandardMaterial({ map: feltTex, normalMap: feltNormal, normalScale: new Vector2(0.55, 0.55), roughness: 0.96, metalness: 0 });
    const cushionMat = new MeshStandardMaterial({ map: feltTex, roughness: 0.9, color: '#d6ded8' });
    const railMat = new MeshPhysicalMaterial({ color: '#0d0d0d', roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.12 });
    const pocketMat = new MeshBasicMaterial({ color: '#020202' });
    const sightMat = new MeshStandardMaterial({ color: '#f4f3ef', roughness: 0.3, emissive: '#ffffff', emissiveIntensity: 0.05 });
    this.disposables.push(feltTex, felt, cushionMat, railMat, pocketMat, sightMat);

    const bed = new Mesh(new PlaneGeometry(HW * 2, HD * 2), felt);
    bed.rotation.x = -Math.PI / 2;
    bed.position.set(TX, 0, TZ);
    bed.receiveShadow = true;
    this.scene.add(bed);

    const box = (w: number, h: number, d: number, x: number, y: number, z: number, mat: MeshStandardMaterial) => {
      const m = new Mesh(new BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z);
      m.receiveShadow = true;
      this.scene.add(m);
      this.disposables.push(m.geometry);
      return m;
    };
    const cushH = 1.27;
    const cushW = 0.9;
    const railW = 2.8;
    const pocketGap = 2.0;
    const midGap = 1.3;
    // long cushions (4 segments)
    for (const sz of [-1, 1]) {
      const z = TZ + sz * (HD - cushW / 2);
      const len = HW - pocketGap - midGap;
      box(len, cushH, cushW, TX - midGap - len / 2, cushH / 2, z, cushionMat);
      box(len, cushH, cushW, TX + midGap + len / 2, cushH / 2, z, cushionMat);
    }
    for (const sx of [-1, 1]) {
      const x = TX + sx * (HW - cushW / 2);
      box(cushW, cushH, HD * 2 - pocketGap * 2, x, cushH / 2, TZ, cushionMat);
    }
    // rails
    const railH = 1.55;
    box(HW * 2 + railW * 2, railH, railW, TX, railH / 2, TZ - HD - railW / 2, railMat);
    box(HW * 2 + railW * 2, railH, railW, TX, railH / 2, TZ + HD + railW / 2, railMat);
    box(railW, railH, HD * 2, TX - HW - railW / 2, railH / 2, TZ, railMat);
    box(railW, railH, HD * 2, TX + HW + railW / 2, railH / 2, TZ, railMat);
    // pockets
    const pocketGeo = new CircleGeometry(1.35, 40);
    this.disposables.push(pocketGeo);
    for (const [px, pz] of [
      [TX - HW, TZ - HD], [TX, TZ - HD - 0.3], [TX + HW, TZ - HD],
      [TX - HW, TZ + HD], [TX, TZ + HD + 0.3], [TX + HW, TZ + HD],
    ]) {
      const m = new Mesh(pocketGeo, pocketMat);
      m.rotation.x = -Math.PI / 2;
      m.position.set(px, 0.006, pz);
      this.scene.add(m);
    }
    // diamond sights
    const sightGeo = new CircleGeometry(0.12, 16);
    this.disposables.push(sightGeo);
    for (let i = 1; i < 8; i++) {
      if (i === 4) continue;
      const x = TX - HW + (i / 8) * HW * 2;
      for (const sz of [-1, 1]) {
        const m = new Mesh(sightGeo, sightMat);
        m.rotation.x = -Math.PI / 2;
        m.position.set(x, railH + 0.005, TZ + sz * (HD + railW / 2));
        this.scene.add(m);
      }
    }
    for (let i = 1; i < 4; i++) {
      const z = TZ - HD + (i / 4) * HD * 2;
      for (const sx of [-1, 1]) {
        const m = new Mesh(sightGeo, sightMat);
        m.rotation.x = -Math.PI / 2;
        m.position.set(TX + sx * (HW + railW / 2), railH + 0.005, z);
        this.scene.add(m);
      }
    }
  }

  // ---------------------------------------------------------------- Public API
  setStoryProgress(p: number) {
    this.storyTarget = clamp(p);
  }
  setFrameworkProgress(f: number) {
    this.fwTarget = clamp(f);
  }
  setFrameworkVisible(on: boolean) {
    this.fwVisible = on ? 1 : 0;
  }

  setRunning(on: boolean) {
    if (this.opts.reduced) return;
    if (on === this.running) return;
    this.running = on;
    if (on) {
      this.last = performance.now();
      this.raf = requestAnimationFrame(this.loop);
    } else cancelAnimationFrame(this.raf);
  }

  resize() {
    const canvas = this.renderer.domElement;
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    this.width = w;
    this.height = h;
    this.renderer.setSize(w, h, false);
    this.cine?.setSize(w, h, this.pixelRatio);
    const aspect = w / h;
    this.portrait = aspect < 1;
    this.camera.aspect = aspect;
    // Dolly out on narrow screens so compositions keep breathing room.
    const need = Math.max(1, 1.55 / aspect);
    this.camPts = KEYS.map((k) => {
      if (this.portrait && k.mpos) return k.mpos.clone();
      const s = Math.min(k.max, need);
      return k.tgt.clone().add(k.pos.clone().sub(k.tgt).multiplyScalar(s));
    });
    this.tgtPts = KEYS.map((k) => k.tgt.clone());
    this.orbitInner.scale.setScalar(this.portrait ? 0.88 : 1);
    if (this.opts.reduced) this.renderFrame(0);
  }

  dispose() {
    this.setRunning(false);
    window.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    const all = [...this.scene.children, ...this.overlay.children];
    all.forEach((root) => root.traverse((o) => {
      if (o instanceof Mesh) {
        o.geometry.dispose();
        const m = o.material as { dispose?: () => void; map?: Texture };
        m.dispose?.();
      }
    }));
    this.disposables.forEach((d) => d.dispose());
    this.cine.dispose();
    this.renderer.dispose();
  }

  // ---------------------------------------------------------------- Interaction
  private hitMarker(e: PointerEvent): number {
    if (!this.orbit.visible || this.fwVisible < 0.5) return -1;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    // generous hit area: test distance from ray to each marker
    let best = -1;
    let bestD = 0.5 * this.orbitInner.scale.x;
    const wp = new Vector3();
    for (const m of this.markers) {
      m.getWorldPosition(wp);
      const d = this.raycaster.ray.distanceToPoint(wp);
      if (d < bestD) {
        bestD = d;
        best = m.userData.index as number;
      }
    }
    return best;
  }
  private onPointerDown = (e: PointerEvent) => {
    const t = e.target as HTMLElement | null;
    if (t && t.closest('a,button,input,textarea,[data-no-orbit]')) return;
    const i = this.hitMarker(e);
    if (i >= 0) this.opts.onStageSelect?.(i);
  };
  private onPointerMove = (e: PointerEvent) => {
    if (this.fwVisible < 0.5) return;
    const i = this.hitMarker(e);
    document.documentElement.style.cursor = i >= 0 ? 'pointer' : '';
  };

  // ---------------------------------------------------------------- Loop
  private loop = (now: number) => {
    const elapsed = Math.min(0.25, (now - this.last) / 1000);
    this.last = now;
    this.renderFrame(elapsed);
    this.adaptQuality(elapsed);
    if (this.running) this.raf = requestAnimationFrame(this.loop);
  };

  private adaptQuality(dt: number) {
    this.frameTimes.push(dt);
    if (this.frameTimes.length < 90) return;
    const avg = this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length;
    this.frameTimes.length = 0;
    if (avg <= 0.026) return;
    if (this.pixelRatio > 1) {
      this.pixelRatio = Math.max(1, this.pixelRatio - 0.25);
      this.renderer.setPixelRatio(this.pixelRatio);
      this.resize();
    } else {
      this.cine.degrade();
    }
  }

  private renderFrame(dt: number) {
    // Smoothing uses real elapsed time so slow devices never lag behind the scroll.
    this.time += Math.min(dt, 0.05);
    // Critically-damped follow of the scroll targets: silky, never laggy.
    const k = dt === 0 ? 1 : 1 - Math.exp(-dt * 9);
    this.story += (this.storyTarget - this.story) * k;
    this.fw += (this.fwTarget - this.fw) * (dt === 0 ? 1 : 1 - Math.exp(-dt * 6));
    if (Math.abs(this.storyTarget - this.story) < 1e-5) this.story = this.storyTarget;
    const p = this.story;

    // ---- Balls
    const t = simTime(p);
    shotAt(t, this.shot);
    this.cueBall.position.copy(this.shot.cue);
    this.cueBall.quaternion.copy(this.shot.cueQ);
    this.eightBall.position.copy(this.shot.eight);
    const turn = (this.fw - 0.5) * 0.42 * range(p, 0.9, 1);
    this.tmpQ.setFromAxisAngle(this.yAxis, turn);
    this.eightBall.quaternion.copy(this.tmpQ).multiply(this.shot.eightQ);
    this.cueBallShadow.position.set(this.shot.cue.x + 0.15, 0.012, this.shot.cue.z + 0.1);
    this.eightBallShadow.position.set(this.shot.eight.x + 0.15, 0.012, this.shot.eight.z + 0.1);

    // ---- Cue
    this.poseCue(p, this.shot.cue.x - C.x);

    // ---- Lights
    const reveal = smooth(range(p, ...STORY.tableReveal));
    const focus = smooth(range(p, ...STORY.focus));
    this.heroSpot.intensity = lerp(5.2, 2.6, reveal) * (1 - focus * 0.7);
    this.mainSpot.intensity = reveal * lerp(3.1, 1.25, focus);
    this.focusSpot.intensity = focus * 5.5;

    // ---- Accents
    const sk = range(p, STORY.contactTip - 0.002, STORY.contactTip + 0.02);
    this.strikeGlow.scale.setScalar(lerp(0.6, 1.8, easeOut(sk)));
    this.strikeGlow.material.opacity = sk > 0 && sk < 1 ? 0.55 * Math.pow(1 - sk, 2) : 0;
    const ik = range(p, PC - 0.002, PC + 0.035);
    this.impactGlow.scale.setScalar(lerp(0.8, 3.2, easeOut(ik)));
    this.impactGlow.material.opacity = ik > 0 && ik < 1 ? 0.6 * Math.pow(1 - ik, 2) : 0;
    // Hero: the table hides in darkness until the cue arrives.
    const fog = this.scene.fog as Fog;
    fog.near = lerp(10, 22, reveal);
    fog.far = lerp(24, 66, reveal);

    // ---- Camera
    hermite(KEYS, this.camPts, p, this.tmpPos);
    hermite(KEYS, this.tgtPts, p, this.tmpTgt);
    // Framework: a slow orbit as visitors move through the dimensions.
    const fwOn = range(p, 0.95, 1);
    if (fwOn > 0) {
      const ang = (this.fw - 0.5) * 0.32 * fwOn;
      const off = this.tmpPos.clone().sub(F);
      off.applyAxisAngle(this.yAxis, ang);
      this.tmpPos.copy(F).add(off);
    }
    // Breathing handheld drift + impact shake.
    const drift = 0.04;
    this.tmpPos.x += Math.sin(this.time * 0.35) * drift;
    this.tmpPos.y += Math.sin(this.time * 0.27 + 1.3) * drift * 0.6;
    const shakeK = p > PC ? Math.exp(-(p - PC) / 0.012) * 0.07 : 0;
    const strikeK = p > STORY.contactTip ? Math.exp(-(p - STORY.contactTip) / 0.006) * 0.03 : 0;
    const sh = shakeK + strikeK;
    if (sh > 0.0005) {
      this.tmpPos.x += Math.sin(p * 1900) * sh;
      this.tmpPos.y += Math.sin(p * 2700 + 1) * sh * 0.7;
    }
    this.camera.position.copy(this.tmpPos);
    this.camera.lookAt(this.tmpTgt);
    this.camera.fov = scalarAt(KEYS, p, (kk) => kk.fov);
    let fx = scalarAt(KEYS, p, (kk) => (this.portrait ? kk.mfx ?? kk.fx : kk.fx));
    let fy = scalarAt(KEYS, p, (kk) => (this.portrait ? kk.mfy ?? kk.fy : kk.fy));
    if (this.opts.reduced) {
      // Poster: keep the shot in the upper frame, clear of the headline.
      fx = this.portrait ? 0.5 : 0.62;
      fy = 0.36;
    }
    if (this.debugCam) {
      const d = this.debugCam;
      this.camera.position.fromArray(d.pos);
      this.camera.lookAt(new Vector3().fromArray(d.tgt));
      this.camera.fov = d.fov ?? this.camera.fov;
      fx = d.fx ?? fx;
      fy = d.fy ?? fy;
    }
    this.camera.setViewOffset(
      this.width,
      this.height,
      (0.5 - fx) * this.width,
      (0.5 - fy) * this.height,
      this.width,
      this.height,
    );
    this.camera.updateProjectionMatrix();

    // ---- 8D orbit
    this.updateOrbit(p);

    // ---- Atmosphere: shafts and dust follow their lamps
    const heroK = this.heroSpot.intensity / 5.2;
    (this.heroShaft.material as ShaderMaterial).uniforms.uIntensity.value = heroK * (1 - reveal * 0.55);
    (this.focusShaft.material as ShaderMaterial).uniforms.uIntensity.value = focus;
    const hd = this.heroDust.material as ShaderMaterial;
    hd.uniforms.uTime.value = this.time;
    hd.uniforms.uIntensity.value = heroK * (1 - reveal * 0.5);
    hd.uniforms.uScale.value = this.pixelRatio;
    const fd = this.focusDust.material as ShaderMaterial;
    fd.uniforms.uTime.value = this.time;
    fd.uniforms.uIntensity.value = focus;
    fd.uniforms.uScale.value = this.pixelRatio;

    // ---- Lens: focus pulls from the cue ball to the eight ball at impact
    const pull = smooth(range(p, PC - 0.03, PC + 0.08));
    this.focusPoint.copy(this.shot.cue).lerp(this.shot.eight, pull);
    const aperture = lerp(0.0024, 0.0011, range(p, 0.05, 0.25)) * (1 - pull) + lerp(0.0011, 0.002, range(p, 0.8, 0.95)) * pull;
    this.cine.setFocus(this.camera.position.distanceTo(this.focusPoint), aperture);
    this.cine.tick(this.time);
    this.cine.composer.render(dt);
  }

  private poseCue(p: number, ballDisp: number) {
    const [e0, e1] = STORY.cueEnter;
    const visible = p > e0 - 0.02 && p < STORY.withdraw[1];
    this.cuePivot.visible = visible;
    this.cueShadow.visible = visible;
    if (!visible) return;
    let gap: number;
    let yaw = 0;
    let elev = 0.1;
    if (p < e1) {
      const u = easeOut(range(p, e0, e1));
      gap = lerp(30, 2.6, u);
      yaw = lerp(0.6, 0, u);
      elev = lerp(0.16, 0.1, u);
    } else if (p < STORY.strokes[1]) {
      const u = range(p, ...STORY.strokes);
      gap = 2.6 + 1.0 * (1 - Math.cos(u * Math.PI * 4)) * 0.5;
    } else if (p < STORY.drawBack[1]) {
      gap = lerp(2.6, 5.4, easeInOut(range(p, ...STORY.drawBack)));
    } else if (p < STORY.contactTip) {
      gap = lerp(5.4, 0, Math.pow(range(p, ...STORY.strike), 1.6));
    } else if (p < STORY.withdraw[0]) {
      gap = lerp(0, -0.55, easeOut(range(p, ...STORY.follow)));
    } else {
      const u = easeInOut(range(p, ...STORY.withdraw));
      gap = lerp(-0.55, 20, u);
      elev = lerp(0.1, 0.24, u);
    }
    // The tip may never pass through the ball's surface.
    gap = Math.max(gap, -ballDisp);
    const dir = new Vector3(-Math.cos(elev) * Math.cos(yaw), Math.sin(elev), Math.cos(elev) * Math.sin(yaw));
    this.cuePivot.quaternion.setFromUnitVectors(this.yAxis, dir);
    this.cuePivot.position.copy(C).addScaledVector(dir, R + gap);
    // soft elongated shadow under the shaft
    const mid = this.cuePivot.position.clone().addScaledVector(dir, 9);
    this.cueShadow.position.set(mid.x + 0.3, 0.011, mid.z + 0.2);
    this.cueShadow.scale.set(18, 1.1, 1);
    this.cueShadow.rotation.z = Math.atan2(dir.z, -dir.x);
    (this.cueShadow.material as MeshBasicMaterial).opacity = 0.32 * (1 - smooth(range(p, 0.49, 0.57)));
  }

  private updateOrbit(p: number) {
    const show = range(p, 0.9, 1);
    this.orbit.visible = show > 0.001;
    if (!this.orbit.visible) return;
    this.orbit.quaternion.copy(this.camera.quaternion);
    const s = lerp(0.82, 1, easeOut(show));
    this.orbit.scale.setScalar(s);
    const alpha = smooth(show);
    (this.orbitBase.material as MeshBasicMaterial).opacity = 0.22 * alpha;

    const f = this.fw * this.fwVisible;
    const fwT = clamp(this.fwTarget);
    const active = Math.min(STAGE_COUNT - 1, Math.floor(fwT * STAGE_COUNT * 0.9999));
    this.activeStage = active;
    // Progress arc from the top, clockwise to the current dimension.
    const arc = Math.max(0.0001, Math.min(f * STAGE_COUNT, STAGE_COUNT - 1) * ((Math.PI * 2) / STAGE_COUNT));
    const q = Math.round(arc * 120) / 120;
    if (q !== this.orbitArcValue) {
      this.orbitArcValue = q;
      this.orbitArc.geometry.dispose();
      this.orbitArc.geometry = new TorusGeometry(ORBIT_R, 0.016, 6, Math.max(2, Math.round(q * 40)), Math.max(0.0001, q));
      this.orbitArc.rotation.z = Math.PI / 2 - q;
    }
    (this.orbitArc.material as MeshBasicMaterial).opacity = alpha;
    this.markers.forEach((m, i) => {
      const isActive = this.fwVisible > 0 && i === active;
      const passed = this.fwVisible > 0 && i < active;
      const target = isActive ? 0.1 : passed ? 0.07 : 0.055;
      m.scale.setScalar(lerp(m.scale.x, target, 0.2));
      const mat = m.material as MeshBasicMaterial;
      mat.opacity = alpha * (isActive ? 1 : passed ? 0.85 : 0.42);
      mat.color.set(passed ? LIGHT_GREEN : '#ffffff');
      const lm = this.labels[i].material as SpriteMaterial;
      lm.opacity = alpha * (isActive ? 1 : passed ? 0.6 : 0.34);
    });
    const am = this.markers[active];
    this.activeHalo.position.lerp(am.position, 0.25);
    const pulse = 1 + Math.sin(this.time * 3) * 0.08;
    this.activeHalo.scale.setScalar(pulse);
    (this.activeHalo.material as MeshBasicMaterial).opacity = alpha * this.fwVisible * 0.9;
  }

  /** Dev-only: pin the camera to explore compositions. */
  debugCam: { pos: number[]; tgt: number[]; fov?: number; fx?: number; fy?: number } | null = null;

  get stage() {
    return this.activeStage;
  }
}
