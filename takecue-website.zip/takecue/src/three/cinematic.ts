import {
  AdditiveBlending,
  BufferAttribute,
  BufferGeometry,
  ConeGeometry,
  DoubleSide,
  HalfFloatType,
  Mesh,
  Points,
  ShaderMaterial,
  Vector2,
  Vector3,
  WebGLRenderTarget,
  type Camera,
  type Scene,
  type WebGLRenderer,
} from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';

/**
 * Final "film" pass, in display space: gentle filmic grade (lifted blacks,
 * warm highlights, slightly muted saturation), lens vignette, faint
 * chromatic fringing toward the frame edges, and animated grain.
 */
const FilmShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uRes: { value: new Vector2(1, 1) },
    uGrain: { value: 0.034 },
    uVignette: { value: 0.38 },
    uAberration: { value: 0.00055 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime, uGrain, uVignette, uAberration;
    uniform vec2 uRes;
    varying vec2 vUv;
    float hash(vec2 p) { p = fract(p * vec2(443.897, 441.423)); p += dot(p, p.yx + 19.19); return fract((p.x + p.y) * p.x); }
    void main() {
      vec2 c = vUv - 0.5;
      float r2 = dot(c, c);
      vec2 off = c * r2 * uAberration * 40.0;
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + off).r;
      col.g = texture2D(tDiffuse, vUv).g;
      col.b = texture2D(tDiffuse, vUv - off).b;
      // grade
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, 0.9);                                  // a touch of restraint
      col = col * vec3(1.03, 1.0, 0.965) + vec3(0.006, 0.008, 0.007); // warm lamp, lifted blacks
      col = smoothstep(vec3(-0.02), vec3(1.04), col);                 // soft S-curve
      // vignette
      float vig = smoothstep(0.85, 0.18, r2 * 2.2);
      col *= mix(1.0 - uVignette, 1.0, vig);
      // grain (luma-weighted so shadows stay clean-ish)
      float g = hash(vUv * uRes + fract(uTime * 7.31) * 100.0) - 0.5;
      col += g * uGrain * (0.55 + 0.45 * (1.0 - l));
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

export type Cinematic = {
  composer: EffectComposer;
  setSize: (w: number, h: number, pixelRatio: number) => void;
  setFocus: (distance: number, aperture: number) => void;
  tick: (time: number) => void;
  /** Drop the most expensive effect still running; false when nothing is left to drop. */
  degrade: () => boolean;
  dispose: () => void;
};

export function createCinematic(
  renderer: WebGLRenderer,
  scene: Scene,
  camera: Camera,
  high: boolean,
  overlay?: Scene,
): Cinematic {
  const target = new WebGLRenderTarget(1, 1, { type: HalfFloatType, samples: high ? 4 : 0 });
  const composer = new EffectComposer(renderer, target);
  composer.addPass(new RenderPass(scene, camera));
  let bokeh: BokehPass | null = null;
  if (high) {
    bokeh = new BokehPass(scene, camera, { focus: 10, aperture: 0.0016, maxblur: 0.0065 });
    composer.addPass(bokeh);
  }
  if (overlay) {
    // UI-like elements (the 8D orbit) stay crisp: drawn after the lens blur.
    const over = new RenderPass(overlay, camera);
    over.clear = false;
    composer.addPass(over);
  }
  const bloom = new UnrealBloomPass(new Vector2(256, 256), high ? 0.26 : 0.2, 0.45, 0.93);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());
  const film = new ShaderPass(FilmShader);
  composer.addPass(film);

  return {
    composer,
    setSize(w, h, pr) {
      composer.setPixelRatio(pr);
      composer.setSize(w, h);
      bloom.resolution.set(w * 0.5, h * 0.5);
      film.uniforms.uRes.value.set(w * pr, h * pr);
    },
    setFocus(distance, aperture) {
      if (!bokeh) return;
      const u = bokeh.uniforms as Record<string, { value: number }>;
      u.focus.value = distance;
      u.aperture.value = aperture;
    },
    tick(time) {
      film.uniforms.uTime.value = time;
    },
    degrade() {
      if (bokeh?.enabled) return !(bokeh.enabled = false);
      if (bloom.enabled) return !(bloom.enabled = false);
      return false;
    },
    dispose() {
      composer.dispose();
      target.dispose();
    },
  };
}

/** A soft volumetric shaft of lamp light, read through the room's haze. */
export function lightShaft(height: number, radiusBottom: number) {
  const geo = new ConeGeometry(radiusBottom, height, 64, 1, true);
  geo.translate(0, -height / 2, 0); // apex at origin, opening downward
  const mat = new ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: AdditiveBlending,
    side: DoubleSide,
    uniforms: { uIntensity: { value: 0 }, uHeight: { value: height } },
    vertexShader: /* glsl */ `
      varying float vH; varying vec3 vN; varying vec3 vView;
      uniform float uHeight;
      void main() {
        vH = -position.y / uHeight;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        vN = normalize(normalMatrix * normal);
        vView = normalize(-mv.xyz);
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying float vH; varying vec3 vN; varying vec3 vView;
      uniform float uIntensity;
      void main() {
        float edge = pow(abs(dot(vN, vView)), 1.6);          // soft silhouette
        float fall = smoothstep(0.0, 0.35, vH) * (1.0 - smoothstep(0.75, 1.0, vH)); // fade at lamp and at felt
        float a = edge * fall * uIntensity * 0.11;
        gl_FragColor = vec4(vec3(1.0, 0.97, 0.9) * a, a);
      }
    `,
  });
  return new Mesh(geo, mat);
}

/** Dust motes drifting slowly through a lamp's beam. */
export function dustMotes(count: number, center: Vector3, radius: number, height: number) {
  const pos = new Float32Array(count * 3);
  const seed = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * radius;
    pos[i * 3] = center.x + Math.cos(a) * r;
    pos[i * 3 + 1] = center.y + 0.4 + Math.random() * height;
    pos[i * 3 + 2] = center.z + Math.sin(a) * r;
    seed[i] = Math.random();
  }
  const geo = new BufferGeometry();
  geo.setAttribute('position', new BufferAttribute(pos, 3));
  geo.setAttribute('seed', new BufferAttribute(seed, 1));
  const mat = new ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: AdditiveBlending,
    uniforms: { uTime: { value: 0 }, uIntensity: { value: 0 }, uScale: { value: 1 } },
    vertexShader: /* glsl */ `
      attribute float seed;
      uniform float uTime, uScale;
      varying float vA;
      void main() {
        vec3 p = position;
        float t = uTime * (0.05 + seed * 0.06);
        p.x += sin(t * 6.2831 + seed * 40.0) * 0.35;
        p.z += cos(t * 5.0 + seed * 23.0) * 0.35;
        p.y += sin(t * 3.0 + seed * 12.0) * 0.25;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = (2.0 + seed * 3.5) * uScale * (10.0 / -mv.z);
        vA = 0.35 + 0.65 * (sin(uTime * (0.6 + seed) + seed * 30.0) * 0.5 + 0.5);
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uIntensity;
      varying float vA;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vA * uIntensity * 0.5;
        gl_FragColor = vec4(vec3(1.0, 0.96, 0.88) * a, a);
      }
    `,
  });
  return new Points(geo, mat);
}
